// Razorpay integration utilities
import crypto from 'crypto';

export interface RazorpayOrder {
  id: string;
  entity: string;
  amount: number;
  amount_paid: number;
  amount_due: number;
  currency: string;
  receipt: string;
  status: string;
  attempts: number;
  notes: Record<string, any>;
  created_at: number;
}

export interface RazorpayPayment {
  id: string;
  entity: string;
  amount: number;
  currency: string;
  status: string;
  method: string;
  description: string;
  amount_refunded: number;
  refund_status: string | null;
  captured: boolean;
  card_id: string | null;
  bank: string | null;
  wallet: string | null;
  vpa: string | null;
  email: string;
  contact: string;
  notes: Record<string, any>;
  fee: number;
  tax: number;
  error_code: string | null;
  error_description: string | null;
  error_source: string | null;
  error_reason: string | null;
  acquirer_data: Record<string, any>;
  created_at: number;
}

export interface VerifySignaturePayload {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

/**
 * Verify Razorpay signature
 * IMPORTANT: This should only be called server-side with the secret key
 */
export function verifyRazorpaySignature(
  orderId: string,
  paymentId: string,
  signature: string,
  secretKey: string
): boolean {
  const body = `${orderId}|${paymentId}`;
  const expectedSignature = crypto
    .createHmac('sha256', secretKey)
    .update(body)
    .digest('hex');
  
  return expectedSignature === signature;
}

/**
 * Format amount for Razorpay (convert to smallest currency unit)
 * INR uses paise (1 INR = 100 paise)
 */
export function formatAmountForRazorpay(amountInRupees: number): number {
  return Math.round(amountInRupees * 100);
}

/**
 * Convert Razorpay amount back to rupees
 */
export function convertRazorpayAmount(amountInPaise: number): number {
  return amountInPaise / 100;
}

/**
 * Generate a unique receipt ID
 */
export function generateReceiptId(userId: string, planId: string): string {
  const timestamp = Date.now();
  return `${userId}-${planId}-${timestamp}`;
}

/**
 * Plan configurations
 */
export const SUBSCRIPTION_PLANS = {
  trial: {
    id: 'trial',
    name: '₹1 Trial',
    amount: 1,
    currency: 'INR',
    period: '7_days',
    description: '7 days of all Pro features for ₹1',
    tag: 'Best to test',
  },
  pro_monthly: {
    id: 'pro_monthly',
    name: 'Pro Monthly',
    amount: 299,
    currency: 'INR',
    period: 'monthly',
    description: 'Unlimited usage, priority support',
    tag: undefined,
  },
  pro_annual: {
    id: 'pro_annual',
    name: 'Pro Annual',
    amount: 2499,
    currency: 'INR',
    period: 'yearly',
    description: 'Save 30% with annual billing',
    tag: 'Best value',
  },
} as const;

export type SubscriptionPlanId = keyof typeof SUBSCRIPTION_PLANS;
