import { doc, getDoc, setDoc, serverTimestamp, Timestamp, updateDoc } from 'firebase/firestore';
import { db } from './firebase';
import { SUBSCRIPTION_PLANS, type SubscriptionPlanId } from './razorpay';

export interface Subscription {
  userId: string;
  planId: SubscriptionPlanId;
  status: 'active' | 'expired' | 'cancelled' | 'pending';
  currentPeriodStart: Timestamp;
  currentPeriodEnd: Timestamp;
  cancelAtPeriodEnd: boolean;
  trialUsed: boolean;
  paymentMethod: string | null;
  lastPaymentId: string | null;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface UsageQuota {
  userId: string;
  toolSlug: string;
  date: string; // YYYY-MM-DD
  count: number;
  limit: number;
  resetAt: Timestamp;
}

/**
 * Get user subscription
 */
export async function getSubscription(userId: string): Promise<Subscription | null> {
  try {
    const docRef = doc(db, 'subscriptions', userId);
    const snapshot = await getDoc(docRef);
    return snapshot.exists() ? (snapshot.data() as Subscription) : null;
  } catch (err) {
    console.error('[subscription] getSubscription error:', err);
    return null;
  }
}

/**
 * Check if user is subscribed to Pro
 */
export async function isUserPro(userId: string): Promise<boolean> {
  const sub = await getSubscription(userId);
  if (!sub) return false;
  
  const now = Date.now();
  const endTime = sub.currentPeriodEnd.toMillis();
  
  return sub.status === 'active' && now < endTime && sub.planId !== 'trial';
}

/**
 * Check if user can use free tier
 */
export async function canUseFree(userId: string, toolSlug: string, freeLimit: number | undefined): Promise<boolean> {
  if (!freeLimit) return true; // Unlimited free
  
  try {
    const today = new Date().toISOString().split('T')[0];
    const quotaRef = doc(db, `users/${userId}/quotas`, `${toolSlug}-${today}`);
    const snapshot = await getDoc(quotaRef);
    
    if (!snapshot.exists()) return true;
    
    const quota = snapshot.data() as UsageQuota;
    return quota.count < freeLimit;
  } catch (err) {
    console.error('[quota] canUseFree error:', err);
    return true; // Allow if error
  }
}

/**
 * Increment usage quota
 */
export async function incrementQuota(userId: string, toolSlug: string, freeLimit: number | undefined): Promise<void> {
  if (!freeLimit) return; // Unlimited
  
  try {
    const today = new Date().toISOString().split('T')[0];
    const quotaRef = doc(db, `users/${userId}/quotas`, `${toolSlug}-${today}`);
    const snapshot = await getDoc(quotaRef);
    
    if (!snapshot.exists()) {
      await setDoc(quotaRef, {
        userId,
        toolSlug,
        date: today,
        count: 1,
        limit: freeLimit,
        resetAt: serverTimestamp(),
      });
    } else {
      await updateDoc(quotaRef, {
        count: snapshot.data().count + 1,
      });
    }
  } catch (err) {
    console.error('[quota] incrementQuota error:', err);
  }
}

/**
 * Create or update subscription
 */
export async function createSubscription(
  userId: string,
  planId: SubscriptionPlanId,
  paymentId: string
): Promise<void> {
  try {
    const plan = SUBSCRIPTION_PLANS[planId];
    const now = serverTimestamp();
    
    let periodEnd = new Date();
    if (planId === 'trial') {
      periodEnd.setDate(periodEnd.getDate() + 7);
    } else if (planId === 'pro_monthly') {
      periodEnd.setMonth(periodEnd.getMonth() + 1);
    } else if (planId === 'pro_annual') {
      periodEnd.setFullYear(periodEnd.getFullYear() + 1);
    }
    
    const docRef = doc(db, 'subscriptions', userId);
    
    await setDoc(docRef, {
      userId,
      planId,
      status: 'active',
      currentPeriodStart: now,
      currentPeriodEnd: Timestamp.fromDate(periodEnd),
      cancelAtPeriodEnd: false,
      trialUsed: planId === 'trial' ? true : false,
      paymentMethod: 'razorpay',
      lastPaymentId: paymentId,
      createdAt: now,
      updatedAt: now,
    } as Subscription);
  } catch (err) {
    console.error('[subscription] createSubscription error:', err);
    throw err;
  }
}

/**
 * Cancel subscription
 */
export async function cancelSubscription(userId: string): Promise<void> {
  try {
    const docRef = doc(db, 'subscriptions', userId);
    await updateDoc(docRef, {
      status: 'cancelled',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    console.error('[subscription] cancelSubscription error:', err);
    throw err;
  }
}
