/**
 * Server-only Firestore + Auth admin helper that talks to Google's REST APIs
 * with a service-account-signed JWT. Worker-runtime safe (no native deps,
 * no gRPC, no firebase-admin import).
 *
 * Requires FIREBASE_SERVICE_ACCOUNT_JSON env var (the full JSON downloaded
 * from Firebase Console → Project Settings → Service Accounts).
 */

interface ServiceAccount {
  project_id: string;
  client_email: string;
  private_key: string;
  token_uri: string;
}

let cachedToken: { token: string; exp: number } | null = null;
let cachedAccount: ServiceAccount | null = null;

function getAccount(): ServiceAccount {
  if (cachedAccount) return cachedAccount;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON not configured");
  const parsed = JSON.parse(raw) as ServiceAccount;
  parsed.private_key = parsed.private_key.replace(/\\n/g, "\n");
  cachedAccount = parsed;
  return parsed;
}

function b64url(buf: ArrayBuffer | Uint8Array | string): string {
  const bytes =
    typeof buf === "string"
      ? new TextEncoder().encode(buf)
      : buf instanceof Uint8Array
        ? buf
        : new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}

async function importPrivateKey(pem: string): Promise<CryptoKey> {
  const body = pem
    .replace(/-----BEGIN PRIVATE KEY-----/, "")
    .replace(/-----END PRIVATE KEY-----/, "")
    .replace(/\s+/g, "");
  const der = Uint8Array.from(atob(body), (c) => c.charCodeAt(0));
  return crypto.subtle.importKey(
    "pkcs8",
    der.buffer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
}

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.exp - 60 > Math.floor(Date.now() / 1000)) {
    return cachedToken.token;
  }
  const account = getAccount();
  const now = Math.floor(Date.now() / 1000);
  const claims = {
    iss: account.client_email,
    scope: "https://www.googleapis.com/auth/datastore",
    aud: account.token_uri,
    iat: now,
    exp: now + 3600,
  };
  const header = { alg: "RS256", typ: "JWT" };
  const unsigned = `${b64url(JSON.stringify(header))}.${b64url(JSON.stringify(claims))}`;
  const key = await importPrivateKey(account.private_key);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
  const jwt = `${unsigned}.${b64url(sig)}`;
  const res = await fetch(account.token_uri, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });
  if (!res.ok) throw new Error(`Token exchange failed: ${await res.text()}`);
  const json = (await res.json()) as { access_token: string; expires_in: number };
  cachedToken = { token: json.access_token, exp: now + json.expires_in };
  return json.access_token;
}

// Convert plain JS values to Firestore REST "Value" objects
function toValue(v: unknown): Record<string, unknown> {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === "string") return { stringValue: v };
  if (typeof v === "boolean") return { booleanValue: v };
  if (typeof v === "number")
    return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(toValue) } };
  if (typeof v === "object")
    return {
      mapValue: {
        fields: Object.fromEntries(Object.entries(v as object).map(([k, val]) => [k, toValue(val)])),
      },
    };
  return { stringValue: String(v) };
}

function fromValue(v: any): any {
  if (!v) return null;
  if ("stringValue" in v) return v.stringValue;
  if ("booleanValue" in v) return v.booleanValue;
  if ("integerValue" in v) return Number(v.integerValue);
  if ("doubleValue" in v) return v.doubleValue;
  if ("nullValue" in v) return null;
  if ("arrayValue" in v) return (v.arrayValue.values ?? []).map(fromValue);
  if ("mapValue" in v)
    return Object.fromEntries(
      Object.entries(v.mapValue.fields ?? {}).map(([k, val]) => [k, fromValue(val)]),
    );
  if ("timestampValue" in v) return v.timestampValue;
  return null;
}

function docUrl(path: string): string {
  const project = getAccount().project_id;
  return `https://firestore.googleapis.com/v1/projects/${project}/databases/(default)/documents/${path}`;
}

export async function getDocument(path: string): Promise<Record<string, any> | null> {
  const token = await getAccessToken();
  const res = await fetch(docUrl(path), {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`getDocument(${path}): ${await res.text()}`);
  const json = (await res.json()) as { fields?: Record<string, any> };
  return json.fields ? Object.fromEntries(Object.entries(json.fields).map(([k, v]) => [k, fromValue(v)])) : {};
}

/**
 * PATCH a document. If updateMask is provided, only those fields are written
 * (merge). Otherwise the document is fully replaced.
 */
export async function setDocument(
  path: string,
  data: Record<string, unknown>,
  options: { merge?: boolean } = {},
): Promise<void> {
  const token = await getAccessToken();
  const fields = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, toValue(v)]));
  const url = new URL(docUrl(path));
  if (options.merge) {
    for (const k of Object.keys(data)) url.searchParams.append("updateMask.fieldPaths", k);
  }
  const res = await fetch(url.toString(), {
    method: "PATCH",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ fields }),
  });
  if (!res.ok) throw new Error(`setDocument(${path}): ${await res.text()}`);
}

export async function createDocument(
  collection: string,
  data: Record<string, unknown>,
  docId?: string,
): Promise<void> {
  const token = await getAccessToken();
  const project = getAccount().project_id;
  const url = new URL(
    `https://firestore.googleapis.com/v1/projects/${project}/databases/(default)/documents/${collection}`,
  );
  if (docId) url.searchParams.set("documentId", docId);
  const fields = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, toValue(v)]));
  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ fields }),
  });
  if (!res.ok && res.status !== 409) {
    throw new Error(`createDocument(${collection}): ${await res.text()}`);
  }
}
