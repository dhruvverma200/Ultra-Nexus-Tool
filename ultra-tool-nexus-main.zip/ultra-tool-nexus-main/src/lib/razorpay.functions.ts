import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Plan catalog — server-side source of truth for amounts.
 * Clients send a plan code only; amounts cannot be tampered with.
 */
export const PLANS = {
  trial: { amount: 100, label: "OmniKit ₹1 Trial (7 days)", days: 7 },
  pro_monthly: { amount: 29900, label: "OmniKit Pro Monthly", days: 30 },
  pro_annual: { amount: 249900, label: "OmniKit Pro Annual", days: 365 },
} as const;
export type PlanCode = keyof typeof PLANS;

const createOrderInput = z.object({
  plan: z.enum(["trial", "pro_monthly", "pro_annual"]),
  uid: z.string().min(1),
  autopayPlan: z.enum(["pro_monthly", "pro_annual"]).optional(),
});

export const createRazorpayOrder = createServerFn({ method: "POST" })
  .inputValidator((d) => createOrderInput.parse(d))
  .handler(async ({ data }) => {
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) throw new Error("Razorpay credentials missing on the server.");

    // Server-side trial guard: reject if user has already used the trial.
    if (data.plan === "trial") {
      try {
        const { getDocument } = await import("./firebase-rest.server");
        const sub = await getDocument(`subscriptions/${data.uid}`);
        if (sub && sub.trialUsed === true) {
          throw new Error("Trial already used on this account");
        }
      } catch (e) {
        // If FIREBASE_SERVICE_ACCOUNT_JSON is missing we still let it through;
        // the client-side check + Firestore rules act as a fallback.
        if (e instanceof Error && e.message === "Trial already used on this account") throw e;
        console.warn("[razorpay] trial guard skipped:", e);
      }
    }

    const plan = PLANS[data.plan];
    const auth = btoa(`${keyId}:${keySecret}`);
    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: plan.amount,
        currency: "INR",
        receipt: `omni_${Date.now()}`,
        payment_capture: 1,
        notes: {
          uid: data.uid,
          plan: data.plan,
          autopayPlan: data.autopayPlan ?? "",
        },
      }),
    });
    if (!res.ok) throw new Error(`Razorpay order create failed: ${await res.text()}`);
    const order = (await res.json()) as { id: string; amount: number; currency: string };
    return { id: order.id, amount: order.amount, currency: order.currency, plan: data.plan };
  });

const verifyInput = z.object({
  orderId: z.string().min(1),
  paymentId: z.string().min(1),
  signature: z.string().min(1),
  uid: z.string().min(1),
  plan: z.enum(["trial", "pro_monthly", "pro_annual"]),
  autopayPlan: z.enum(["pro_monthly", "pro_annual"]).optional(),
});

export const verifyRazorpayPayment = createServerFn({ method: "POST" })
  .inputValidator((d) => verifyInput.parse(d))
  .handler(async ({ data }) => {
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keySecret) throw new Error("Razorpay secret missing on the server.");
    const { createHmac } = await import("node:crypto");
    const expected = createHmac("sha256", keySecret)
      .update(`${data.orderId}|${data.paymentId}`)
      .digest("hex");
    if (expected !== data.signature) return { valid: false as const };

    // Persist subscription server-side via service account (authoritative).
    const plan = PLANS[data.plan];
    const periodEnd = Date.now() + plan.days * 24 * 60 * 60 * 1000;
    try {
      const { setDocument, createDocument } = await import("./firebase-rest.server");
      await setDocument(
        `subscriptions/${data.uid}`,
        {
          uid: data.uid,
          plan: data.plan,
          status: "active",
          trialUsed: data.plan === "trial" ? true : undefined,
          currentPeriodEnd: periodEnd,
          autopayPlan: data.autopayPlan ?? null,
          lastPaymentId: data.paymentId,
          lastOrderId: data.orderId,
          updatedAt: Date.now(),
        },
        { merge: true },
      );
      await createDocument("audit_logs", {
        type: "payment_verified",
        uid: data.uid,
        plan: data.plan,
        paymentId: data.paymentId,
        orderId: data.orderId,
        at: Date.now(),
      });
    } catch (e) {
      console.warn("[razorpay] server-side persist failed (client will fall back):", e);
    }

    return { valid: true as const, plan: data.plan, currentPeriodEnd: periodEnd };
  });
