import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  onAuthStateChanged,
  signOut as fbSignOut,
  type User,
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, ADMIN_EMAIL } from "./firebase";

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  signOut: () => Promise<void>;
  refreshRole: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function ensureUserDocs(user: User): Promise<"admin" | "user"> {
  const userRef = doc(db, "users", user.uid);
  const userSnap = await getDoc(userRef);
  if (!userSnap.exists()) {
    await setDoc(userRef, {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName ?? null,
      photoURL: user.photoURL ?? null,
      createdAt: serverTimestamp(),
    });
  }

  const roleRef = doc(db, "user_roles", user.uid);
  const roleSnap = await getDoc(roleRef);
  if (roleSnap.exists()) {
    return (roleSnap.data().role as "admin" | "user") ?? "user";
  }

  const role: "admin" | "user" = user.email === ADMIN_EMAIL ? "admin" : "user";
  await setDoc(roleRef, {
    uid: user.uid,
    role,
    createdAt: serverTimestamp(),
  });
  return role;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  const refreshRole = async () => {
    if (!auth.currentUser) {
      setIsAdmin(false);
      return;
    }
    try {
      const role = await ensureUserDocs(auth.currentUser);
      setIsAdmin(role === "admin");
    } catch (err) {
      console.warn("[auth] refreshRole failed", err);
    }
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        try {
          const role = await ensureUserDocs(u);
          setIsAdmin(role === "admin");
        } catch (err) {
          console.warn("[auth] ensureUserDocs failed", err);
          setIsAdmin(false);
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      isAdmin,
      signOut: async () => {
        await fbSignOut(auth);
      },
      refreshRole,
    }),
    [user, loading, isAdmin],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
