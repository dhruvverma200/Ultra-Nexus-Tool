export type ToolCategory =
  | "pdf"
  | "image"
  | "media"
  | "text"
  | "developer"
  | "calculator"
  | "utility";

export interface Tool {
  slug: string;
  name: string;
  description: string;
  category: ToolCategory;
  icon: string; // lucide icon name
  /** If set, /tools/editor?mode=... is used instead of /tools/:slug. */
  editorMode?: "sign" | "stamp" | "annotate" | "fill" | "edit";
  /** Marks tools that have a working implementation. */
  implemented?: boolean;
  /** Free-tier daily limit. undefined = unlimited */
  freeLimit?: number;
}

export const CATEGORIES: { id: ToolCategory; label: string; description: string }[] = [
  { id: "pdf", label: "PDF Tools", description: "Edit, convert, sign and organize PDFs." },
  { id: "image", label: "Image Tools", description: "Compress, convert, edit and enhance images." },
  { id: "media", label: "Video & Audio", description: "Trim, convert and process media files." },
  { id: "text", label: "Text Tools", description: "Format, count, encode and generate text." },
  { id: "developer", label: "Developer Tools", description: "Format, decode and inspect code & data." },
  { id: "calculator", label: "Calculators", description: "Everyday financial and unit calculators." },
  { id: "utility", label: "Utilities", description: "Notes, timers, shorteners and more." },
];

export const TOOLS: Tool[] = [
  // ---------- PDF (25) ----------
  { slug: "pdf-merge", name: "Merge PDF", description: "Combine multiple PDFs into one document.", category: "pdf", icon: "FilePlus", freeLimit: 5 },
  { slug: "pdf-split", name: "Split PDF", description: "Split a PDF into separate files.", category: "pdf", icon: "Scissors", freeLimit: 5 },
  { slug: "pdf-compress", name: "Compress PDF", description: "Reduce PDF file size without quality loss.", category: "pdf", icon: "Minimize2", freeLimit: 5 },
  { slug: "pdf-to-word", name: "PDF to Word", description: "Convert PDF to editable DOCX.", category: "pdf", icon: "FileText", freeLimit: 3 },
  { slug: "pdf-to-excel", name: "PDF to Excel", description: "Extract tables from PDF into XLSX.", category: "pdf", icon: "Table", freeLimit: 3 },
  { slug: "pdf-to-ppt", name: "PDF to PowerPoint", description: "Convert PDF pages into PPTX slides.", category: "pdf", icon: "Presentation", freeLimit: 3 },
  { slug: "pdf-to-jpg", name: "PDF to JPG", description: "Export every PDF page as a JPG image.", category: "pdf", icon: "Image", freeLimit: 5 },
  { slug: "word-to-pdf", name: "Word to PDF", description: "Convert DOCX documents to PDF.", category: "pdf", icon: "FileText", freeLimit: 5 },
  { slug: "excel-to-pdf", name: "Excel to PDF", description: "Convert XLSX spreadsheets to PDF.", category: "pdf", icon: "Table", freeLimit: 5 },
  { slug: "ppt-to-pdf", name: "PowerPoint to PDF", description: "Convert PPTX presentations to PDF.", category: "pdf", icon: "Presentation", freeLimit: 5 },
  { slug: "jpg-to-pdf", name: "JPG to PDF", description: "Turn JPG / PNG images into a single PDF.", category: "pdf", icon: "Image", freeLimit: 10, implemented: true },
  { slug: "pdf-edit", name: "Edit PDF", description: "Add text, images and shapes to a PDF.", category: "pdf", icon: "Edit3", editorMode: "edit" },
  { slug: "pdf-sign", name: "Sign PDF", description: "Draw or upload your signature and apply it.", category: "pdf", icon: "PenLine", editorMode: "sign" },
  { slug: "pdf-stamp", name: "Stamp PDF", description: "Place stamps like Approved, Draft, Confidential.", category: "pdf", icon: "Stamp", editorMode: "stamp" },
  { slug: "pdf-watermark", name: "Watermark PDF", description: "Add a text or image watermark.", category: "pdf", icon: "Droplet" },
  { slug: "pdf-rotate", name: "Rotate PDF", description: "Rotate pages 90 / 180 / 270 degrees.", category: "pdf", icon: "RotateCw" },
  { slug: "pdf-unlock", name: "Unlock PDF", description: "Remove password protection from a PDF.", category: "pdf", icon: "Unlock" },
  { slug: "pdf-protect", name: "Protect PDF", description: "Add a password and encryption to a PDF.", category: "pdf", icon: "Lock" },
  { slug: "pdf-organize", name: "Organize Pages", description: "Reorder, rotate and remove PDF pages.", category: "pdf", icon: "LayoutGrid" },
  { slug: "pdf-delete-pages", name: "Delete PDF Pages", description: "Remove specific pages from a PDF.", category: "pdf", icon: "Trash2" },
  { slug: "pdf-extract-pages", name: "Extract PDF Pages", description: "Pull selected pages into a new PDF.", category: "pdf", icon: "Copy" },
  { slug: "pdf-page-numbers", name: "Add Page Numbers", description: "Insert customizable page numbers.", category: "pdf", icon: "Hash" },
  { slug: "pdf-ocr", name: "OCR PDF", description: "Make scanned PDFs searchable.", category: "pdf", icon: "ScanText" },
  { slug: "pdf-redact", name: "Redact PDF", description: "Permanently black out sensitive information.", category: "pdf", icon: "EyeOff" },
  { slug: "pdf-compare", name: "Compare PDFs", description: "Highlight differences between two PDFs.", category: "pdf", icon: "GitCompare" },
  { slug: "pdf-annotate", name: "Annotate PDF", description: "Highlight, underline and add sticky notes.", category: "pdf", icon: "Highlighter", editorMode: "annotate" },
  { slug: "pdf-fill", name: "Fill PDF Form", description: "Fill out PDF form fields and export.", category: "pdf", icon: "FormInput", editorMode: "fill" },

  // ---------- Image (20) ----------
  { slug: "image-compress", name: "Compress Image", description: "Reduce image size while keeping quality.", category: "image", icon: "Minimize2", freeLimit: 20, implemented: true },
  { slug: "image-resize", name: "Resize Image", description: "Change image width and height.", category: "image", icon: "Maximize2", freeLimit: 20, implemented: true },
  { slug: "image-crop", name: "Crop Image", description: "Crop to a custom selection or aspect ratio.", category: "image", icon: "Crop" },
  { slug: "image-convert", name: "Image Converter", description: "Convert between JPG, PNG, WebP and AVIF.", category: "image", icon: "RefreshCw", implemented: true },
  { slug: "image-remove-bg", name: "Remove Background", description: "Erase the background from any photo.", category: "image", icon: "Eraser" },
  { slug: "image-watermark-remove", name: "Watermark Remover", description: "Remove logos and watermarks from images.", category: "image", icon: "EraserIcon" },
  { slug: "image-to-text", name: "Image to Text (OCR)", description: "Extract text from any image.", category: "image", icon: "ScanText" },
  { slug: "color-picker", name: "Color Picker", description: "Pick colors from an uploaded image.", category: "image", icon: "Pipette" },
  { slug: "image-enhancer", name: "Image Enhancer", description: "AI upscale and enhance image clarity.", category: "image", icon: "Sparkles" },
  { slug: "photo-filter", name: "Photo Filter", description: "Apply premium filters to your photos.", category: "image", icon: "Wand2" },
  { slug: "meme-generator", name: "Meme Generator", description: "Create memes with top and bottom text.", category: "image", icon: "Smile" },
  { slug: "collage-maker", name: "Collage Maker", description: "Combine multiple photos into one collage.", category: "image", icon: "Grid2x2" },
  { slug: "gif-maker", name: "GIF Maker", description: "Turn images or video into an animated GIF.", category: "image", icon: "FileImage" },
  { slug: "image-splitter", name: "Image Splitter", description: "Slice an image into a perfect grid.", category: "image", icon: "Grid3x3" },
  { slug: "image-pixelate", name: "Pixelate", description: "Pixelate parts of an image for privacy.", category: "image", icon: "Squircle" },
  { slug: "image-blur", name: "Blur Image", description: "Apply Gaussian blur to images.", category: "image", icon: "CircleDot" },
  { slug: "image-rotate", name: "Rotate Image", description: "Rotate an image to any angle.", category: "image", icon: "RotateCw" },
  { slug: "image-flip", name: "Flip Image", description: "Flip horizontally or vertically.", category: "image", icon: "FlipHorizontal" },
  { slug: "exif-viewer", name: "EXIF Viewer", description: "Inspect EXIF metadata from your photos.", category: "image", icon: "Info" },
  { slug: "favicon-generator", name: "Favicon Generator", description: "Generate favicons for every device.", category: "image", icon: "Star" },

  // ---------- Media (10) ----------
  { slug: "video-compress", name: "Compress Video", description: "Reduce video file size.", category: "media", icon: "Minimize2" },
  { slug: "video-trim", name: "Trim Video", description: "Cut clips from any video.", category: "media", icon: "Scissors" },
  { slug: "video-convert", name: "Video Converter", description: "Convert video between MP4, WebM, MOV.", category: "media", icon: "RefreshCw" },
  { slug: "audio-convert", name: "Audio Converter", description: "Convert audio between MP3, WAV, OGG.", category: "media", icon: "RefreshCw" },
  { slug: "mp3-cutter", name: "MP3 Cutter", description: "Cut a section from any MP3.", category: "media", icon: "Scissors" },
  { slug: "video-to-gif", name: "Video to GIF", description: "Turn videos into shareable GIFs.", category: "media", icon: "FileImage" },
  { slug: "audio-merger", name: "Audio Merger", description: "Combine multiple audio files.", category: "media", icon: "Layers" },
  { slug: "volume-booster", name: "Volume Booster", description: "Boost the volume of audio tracks.", category: "media", icon: "Volume2" },
  { slug: "subtitle-generator", name: "Subtitle Generator", description: "Auto generate subtitles for videos.", category: "media", icon: "Captions" },
  { slug: "screen-recorder", name: "Screen Recorder", description: "Record your screen right in the browser.", category: "media", icon: "Monitor" },

  // ---------- Text (15) ----------
  { slug: "word-counter", name: "Word Counter", description: "Count words, characters and reading time.", category: "text", icon: "Type", implemented: true },
  { slug: "case-converter", name: "Case Converter", description: "Convert text to upper, lower, title and more.", category: "text", icon: "CaseSensitive", implemented: true },
  { slug: "lorem-ipsum", name: "Lorem Ipsum Generator", description: "Generate placeholder text.", category: "text", icon: "AlignLeft", implemented: true },
  { slug: "text-diff", name: "Text Diff", description: "Compare two texts side by side.", category: "text", icon: "GitCompare" },
  { slug: "markdown-editor", name: "Markdown Editor", description: "Write and preview markdown in real time.", category: "text", icon: "FileCode" },
  { slug: "json-formatter", name: "JSON Formatter", description: "Format, validate and minify JSON.", category: "text", icon: "Braces", implemented: true },
  { slug: "xml-formatter", name: "XML Formatter", description: "Pretty print XML documents.", category: "text", icon: "Code" },
  { slug: "csv-to-json", name: "CSV to JSON", description: "Convert CSV into JSON instantly.", category: "text", icon: "ArrowRightLeft" },
  { slug: "base64", name: "Base64 Encode/Decode", description: "Encode and decode Base64 strings.", category: "text", icon: "Binary", implemented: true },
  { slug: "url-encode", name: "URL Encode/Decode", description: "Encode and decode URL components.", category: "text", icon: "Link2", implemented: true },
  { slug: "hash-generator", name: "Hash Generator", description: "Generate MD5, SHA-1, SHA-256 hashes.", category: "text", icon: "Fingerprint", implemented: true },
  { slug: "password-generator", name: "Password Generator", description: "Generate strong random passwords.", category: "text", icon: "KeyRound", implemented: true },
  { slug: "qr-generator", name: "QR Code Generator", description: "Generate QR codes for any text or URL.", category: "text", icon: "QrCode" },
  { slug: "barcode-generator", name: "Barcode Generator", description: "Generate barcodes in various formats.", category: "text", icon: "Barcode" },
  { slug: "regex-tester", name: "Regex Tester", description: "Test regular expressions against text.", category: "text", icon: "Regex" },

  // ---------- Developer (15) ----------
  { slug: "jwt-decoder", name: "JWT Decoder", description: "Decode and inspect JWT tokens.", category: "developer", icon: "KeyRound", implemented: true },
  { slug: "color-converter", name: "Color Converter", description: "Convert between HEX, RGB, HSL and OKLCH.", category: "developer", icon: "Palette" },
  { slug: "css-minifier", name: "CSS Minifier", description: "Minify CSS to reduce file size.", category: "developer", icon: "Code" },
  { slug: "js-minifier", name: "JS Minifier", description: "Minify JavaScript code.", category: "developer", icon: "FileCode" },
  { slug: "html-formatter", name: "HTML Formatter", description: "Format and beautify HTML markup.", category: "developer", icon: "Code" },
  { slug: "sql-formatter", name: "SQL Formatter", description: "Format SQL queries for readability.", category: "developer", icon: "Database" },
  { slug: "cron-builder", name: "Cron Expression Builder", description: "Build and explain cron schedules.", category: "developer", icon: "Clock" },
  { slug: "uuid-generator", name: "UUID Generator", description: "Generate v4 UUIDs.", category: "developer", icon: "Hash", implemented: true },
  { slug: "ip-lookup", name: "IP Lookup", description: "Lookup geolocation for any IP address.", category: "developer", icon: "Globe" },
  { slug: "dns-lookup", name: "DNS Lookup", description: "Query DNS records for any domain.", category: "developer", icon: "Globe" },
  { slug: "http-status", name: "HTTP Status Codes", description: "Reference all HTTP status codes.", category: "developer", icon: "AlertCircle" },
  { slug: "mime-checker", name: "MIME Type Checker", description: "Find MIME types for file extensions.", category: "developer", icon: "FileType" },
  { slug: "unix-timestamp", name: "Unix Timestamp", description: "Convert Unix timestamps to dates.", category: "developer", icon: "Clock", implemented: true },
  { slug: "diff-checker", name: "Diff Checker", description: "Show differences between two texts.", category: "developer", icon: "GitCompare" },
  { slug: "code-beautifier", name: "Code Beautifier", description: "Beautify code in many languages.", category: "developer", icon: "Sparkles" },

  // ---------- Calculator (10) ----------
  { slug: "emi-calculator", name: "EMI Calculator", description: "Calculate loan EMI, interest and total payment.", category: "calculator", icon: "Calculator", implemented: true },
  { slug: "gst-calculator", name: "GST Calculator", description: "Add or remove GST from any amount.", category: "calculator", icon: "Receipt", implemented: true },
  { slug: "age-calculator", name: "Age Calculator", description: "Find exact age in years, months and days.", category: "calculator", icon: "Cake", implemented: true },
  { slug: "bmi-calculator", name: "BMI Calculator", description: "Calculate Body Mass Index.", category: "calculator", icon: "Activity", implemented: true },
  { slug: "percentage-calculator", name: "Percentage Calculator", description: "Calculate percentages quickly.", category: "calculator", icon: "Percent", implemented: true },
  { slug: "tip-calculator", name: "Tip Calculator", description: "Split bills and calculate tip.", category: "calculator", icon: "Calculator" },
  { slug: "currency-converter", name: "Currency Converter", description: "Convert between world currencies.", category: "calculator", icon: "DollarSign" },
  { slug: "unit-converter", name: "Unit Converter", description: "Convert length, weight, temperature and more.", category: "calculator", icon: "Ruler" },
  { slug: "date-calculator", name: "Date Calculator", description: "Add or subtract days from a date.", category: "calculator", icon: "Calendar" },
  { slug: "loan-calculator", name: "Loan Calculator", description: "Detailed loan amortization schedule.", category: "calculator", icon: "Banknote" },

  // ---------- Utility (5) ----------
  { slug: "url-shortener", name: "URL Shortener", description: "Create short, shareable links.", category: "utility", icon: "Link" },
  { slug: "notes", name: "Notes", description: "Quick cloud-synced notes (account required).", category: "utility", icon: "StickyNote" },
  { slug: "pomodoro", name: "Pomodoro Timer", description: "Focus with the Pomodoro technique.", category: "utility", icon: "Timer", implemented: true },
  { slug: "stopwatch", name: "Stopwatch", description: "Precision stopwatch with lap times.", category: "utility", icon: "Timer", implemented: true },
  { slug: "world-clock", name: "World Clock", description: "See current time across major cities.", category: "utility", icon: "Globe", implemented: true },
];

export function getToolBySlug(slug: string): Tool | undefined {
  return TOOLS.find((t) => t.slug === slug);
}

export function getToolsByCategory(category: ToolCategory): Tool[] {
  return TOOLS.filter((t) => t.category === category);
}

export function getToolHref(tool: Tool): string {
  if (tool.editorMode) return `/tools/editor?mode=${tool.editorMode}`;
  return `/tools/${tool.slug}`;
}
