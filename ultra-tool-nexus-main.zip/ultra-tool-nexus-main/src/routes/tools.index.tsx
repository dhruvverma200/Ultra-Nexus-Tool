import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { TOOLS, CATEGORIES, type ToolCategory } from "@/lib/tools";
import { ToolCard } from "@/components/ToolCard";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export const Route = createFileRoute("/tools/")({
  head: () => ({
    meta: [
      { title: "All tools — OmniKit" },
      { name: "description", content: "Browse 100+ PDF, image, video, text, developer and calculator tools." },
      { property: "og:title", content: "All tools — OmniKit" },
      { property: "og:description", content: "Browse 100+ premium online tools, all in one workspace." },
    ],
    links: [{ rel: "canonical", href: "/tools" }],
  }),
  component: ToolsIndex,
});

function ToolsIndex() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<ToolCategory | "all">("all");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return TOOLS.filter(
      (t) =>
        (cat === "all" || t.category === cat) &&
        (!s || t.name.toLowerCase().includes(s) || t.description.toLowerCase().includes(s)),
    );
  }, [q, cat]);

  return (
    <>
      <section className="relative overflow-hidden border-b border-border/60">
        <div className="absolute inset-0 bg-aurora opacity-70" aria-hidden />
        <div className="container relative mx-auto px-4 py-16 text-center">
          <h1 className="font-display text-4xl md:text-5xl font-bold">All tools</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">100+ premium tools across PDF, image, media, text, dev and calculators.</p>
          <div className="relative mx-auto mt-6 max-w-lg">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search 100+ tools…"
              className="pl-9 h-11 bg-card"
            />
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-10">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setCat("all")}
            className={`rounded-full border px-4 py-1.5 text-sm transition ${cat === "all" ? "bg-gradient-brand text-brand-foreground border-transparent shadow-glow" : "border-border hover:border-brand/60"}`}
          >
            All
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${cat === c.id ? "bg-gradient-brand text-brand-foreground border-transparent shadow-glow" : "border-border hover:border-brand/60"}`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {cat === "all" ? (
          <div className="mt-10 space-y-12">
            {CATEGORIES.map((c) => {
              const items = filtered.filter((t) => t.category === c.id);
              if (items.length === 0) return null;
              return (
                <div key={c.id}>
                  <div className="mb-4">
                    <h2 className="font-display text-2xl font-bold">{c.label}</h2>
                    <p className="text-sm text-muted-foreground">{c.description}</p>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    {items.map((t) => <ToolCard key={t.slug} tool={t} />)}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((t) => <ToolCard key={t.slug} tool={t} />)}
          </div>
        )}

        {filtered.length === 0 && (
          <p className="mt-10 text-center text-muted-foreground">No tools match your search.</p>
        )}
      </section>
    </>
  );
}
