import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, orderBy, query, where, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface Post {
  id: string;
  slug: string;
  title: string;
  excerpt?: string;
  coverImage?: string;
  publishedAt?: { seconds: number };
}

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Blog — OmniKit" },
      { name: "description", content: "Tutorials, product updates and tips from the OmniKit team." },
      { property: "og:title", content: "Blog — OmniKit" },
      { property: "og:description", content: "Tutorials, product updates and tips from the OmniKit team." },
    ],
    links: [{ rel: "canonical", href: "/blog" }],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  const [posts, setPosts] = useState<Post[] | null>(null);
  useEffect(() => {
    (async () => {
      try {
        const q = query(collection(db, "blog_posts"), where("published", "==", true), orderBy("publishedAt", "desc"), limit(50));
        const snap = await getDocs(q);
        setPosts(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
      } catch {
        setPosts([]);
      }
    })();
  }, []);

  return (
    <div className="container mx-auto px-4 py-14">
      <h1 className="font-display text-4xl font-bold">From the blog</h1>
      <p className="mt-2 text-muted-foreground">Tutorials, product updates and behind-the-scenes.</p>

      {posts === null ? (
        <div className="mt-10 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : posts.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-border bg-card/40 p-10 text-center text-muted-foreground">
          No posts yet. Check back soon.
        </div>
      ) : (
        <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((p) => (
            <Link key={p.id} to="/blog/$slug" params={{ slug: p.slug }}>
              <Card className="p-5 h-full transition hover:border-brand/50 hover:shadow-glow">
                {p.coverImage && <img src={p.coverImage} alt="" className="mb-4 h-40 w-full rounded-lg object-cover" loading="lazy" />}
                <h2 className="font-display text-lg font-semibold">{p.title}</h2>
                {p.excerpt && <p className="mt-2 text-sm text-muted-foreground line-clamp-3">{p.excerpt}</p>}
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
