import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { PdfEditor } from "@/components/tools/PdfEditor";

const searchSchema = z.object({
  mode: z.enum(["sign", "stamp", "annotate", "fill", "edit"]).default("edit"),
});

export const Route = createFileRoute("/tools/editor")({
  validateSearch: (s) => searchSchema.parse(s),
  head: ({ match }) => {
    const mode = (match.search as { mode: string }).mode;
    const titles: Record<string, string> = {
      sign: "Sign PDF",
      stamp: "Stamp PDF",
      annotate: "Annotate PDF",
      fill: "Fill PDF Form",
      edit: "Edit PDF",
    };
    return {
      meta: [
        { title: `${titles[mode] ?? "Edit PDF"} — OmniKit` },
        { name: "description", content: "Premium browser-based PDF editor — sign, stamp, annotate, fill or edit your documents." },
      ],
      links: [{ rel: "canonical", href: "/tools/editor" }],
    };
  },
  component: EditorPage,
});

function EditorPage() {
  const { mode } = Route.useSearch();
  return (
    <div className="container mx-auto px-4 py-10">
      <PdfEditor mode={mode} />
    </div>
  );
}
