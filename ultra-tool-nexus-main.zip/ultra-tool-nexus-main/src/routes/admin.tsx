import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';
import { useEffect } from 'react';
import { AlertCircle } from 'lucide-react';

export const Route = createFileRoute('/admin')(() => {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate({ to: '/' });
    }
  }, [user, isAdmin, loading, navigate]);

  if (loading) {
    return (
      <PageShell>
        <div className="container mx-auto px-4 py-10">
          <div className="h-64 bg-card rounded-2xl border border-border/60 animate-pulse" />
        </div>
      </PageShell>
    );
  }

  if (!isAdmin) {
    return (
      <PageShell>
        <div className="container mx-auto px-4 py-20 text-center">
          <Card className="p-8 max-w-md mx-auto">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-destructive/15 text-destructive mb-4">
              <AlertCircle className="h-6 w-6" />
            </div>
            <h1 className="font-display text-xl font-bold">Access Denied</h1>
            <p className="mt-2 text-sm text-muted-foreground">You don't have permission to access this page.</p>
          </Card>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold">Admin Panel</h1>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <Card className="p-6">
            <h2 className="font-display text-lg font-semibold">Users</h2>
            <p className="mt-2 text-sm text-muted-foreground">Manage users and roles</p>
          </Card>
          <Card className="p-6">
            <h2 className="font-display text-lg font-semibold">Payments</h2>
            <p className="mt-2 text-sm text-muted-foreground">View payment history</p>
          </Card>
          <Card className="p-6">
            <h2 className="font-display text-lg font-semibold">Analytics</h2>
            <p className="mt-2 text-sm text-muted-foreground">View usage statistics</p>
          </Card>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
