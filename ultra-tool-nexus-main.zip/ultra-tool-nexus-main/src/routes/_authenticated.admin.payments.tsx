import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/payments")({
  head: () => ({ meta: [{ title: "Payments — Admin" }, { name: "robots", content: "noindex" }] }),
  component: PaymentsPage,
});

function PaymentsPage() {
  const [rows, setRows] = useState<any[] | null>(null);
  useEffect(() => {
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, "subscriptions"), orderBy("updatedAt", "desc")));
        setRows(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch { setRows([]); }
    })();
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Payments & Subscriptions</h1>
      <div className="mt-6">
        {rows === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
          : rows.length === 0 ? <Card className="p-10 text-center text-muted-foreground">No subscriptions yet.</Card>
            : <div className="space-y-2">
                {rows.map((r) => (
                  <Card key={r.id} className="p-4 flex justify-between items-center">
                    <div className="text-sm"><div className="font-medium">{r.plan}</div><div className="text-xs text-muted-foreground">{r.uid}</div></div>
                    <div className="text-xs text-muted-foreground">{r.status}{r.currentPeriodEnd ? ` · ends ${new Date(r.currentPeriodEnd).toLocaleDateString()}` : ""}</div>
                  </Card>
                ))}
              </div>}
      </div>
    </div>
  );
}
