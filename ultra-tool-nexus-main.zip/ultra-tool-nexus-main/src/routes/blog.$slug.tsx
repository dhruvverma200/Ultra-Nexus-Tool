import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import ReactMarkdown from "react-markdown";
import { Loader2, ArrowLeft } from "lucide-react";

interface Post {
  id: string;
  slug: string;
  title: string;
  excerpt?: string;
  content: string;
  coverImage?: string;
  author?: string;
  publishedAt?: { seconds: number };
}

export const Route = createFileRoute("/blog/$slug")({
  component: PostPage,
  notFoundComponent: () => (
    <div className="container mx-auto px-4 py-20 text-center">
      <h1 className="font-display text-3xl font-bold">Post not found</h1>
      <Link to="/blog" className="mt-4 inline-block text-brand hover:underline">Back to blog</Link>
    </div>
  ),
});

function PostPage() {
  const { slug } = Route.useParams();
  const [post, setPost] = useState<Post | null | undefined>(undefined);
  useEffect(() => {
    (async () => {
      try {
        const q = query(collection(db, "blog_posts"), where("slug", "==", slug), where("published", "==", true), limit(1));
        const snap = await getDocs(q);
        if (snap.empty) { setPost(null); return; }
        const d = snap.docs[0];
        setPost({ id: d.id, ...(d.data() as any) });
      } catch {
        setPost(null);
      }
    })();
  }, [slug]);

  if (post === undefined) return <div className="container mx-auto px-4 py-20 text-center"><Loader2 className="inline h-6 w-6 animate-spin text-brand" /></div>;
  if (post === null) throw notFound();

  return (
    <article className="container mx-auto max-w-3xl px-4 py-12">
      <Link to="/blog" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Back to blog</Link>
      <h1 className="mt-4 font-display text-4xl font-bold">{post.title}</h1>
      {post.author && <p className="mt-2 text-sm text-muted-foreground">By {post.author}</p>}
      {post.coverImage && <img src={post.coverImage} alt="" className="mt-6 rounded-2xl border border-border" loading="lazy" />}
      <div className="prose prose-neutral dark:prose-invert mt-8 max-w-none">
        <ReactMarkdown>{post.content}</ReactMarkdown>
      </div>
    </article>
  );
}
