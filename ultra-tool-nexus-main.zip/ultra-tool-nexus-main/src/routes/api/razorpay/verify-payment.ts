import { json } from '@tanstack/react-start';
import { z } from 'zod';
import crypto from 'crypto';
import { createSubscription } from '@/lib/subscription';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';

const RAZORPAY_SECRET_KEY = process.env.RAZORPAY_SECRET_KEY || '';

const verifySignatureSchema = z.object({
  razorpay_order_id: z.string(),
  razorpay_payment_id: z.string(),
  razorpay_signature: z.string(),
  userId: z.string(),
  planId: z.string(),
});

/**
 * Verify Razorpay payment signature and create subscription
 * POST /api/razorpay/verify-payment
 */
export async function POST(request: Request) {
  try {
    const data = verifySignatureSchema.parse(await request.json());

    // Verify signature
    const body = `${data.razorpay_order_id}|${data.razorpay_payment_id}`;
    const expectedSignature = crypto
      .createHmac('sha256', RAZORPAY_SECRET_KEY)
      .update(body)
      .digest('hex');

    if (expectedSignature !== data.razorpay_signature) {
      return json(
        { success: false, error: 'Invalid signature' },
        { status: 400 }
      );
    }

    // Fetch payment details from Razorpay for verification
    const paymentResponse = await fetch(
      `https://api.razorpay.com/v1/payments/${data.razorpay_payment_id}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Basic ${Buffer.from(`${process.env.VITE_RAZORPAY_KEY_ID}:${RAZORPAY_SECRET_KEY}`).toString('base64')}`,
        },
      }
    );

    if (!paymentResponse.ok) {
      throw new Error('Failed to verify payment with Razorpay');
    }

    const payment = await paymentResponse.json();

    if (payment.status !== 'captured') {
      return json(
        { success: false, error: 'Payment not captured' },
        { status: 400 }
      );
    }

    // Create subscription in Firestore
    await createSubscription(data.userId, data.planId as any, data.razorpay_payment_id);

    // Fetch updated subscription
    const subscriptionRef = doc(db, 'subscriptions', data.userId);
    const subscriptionSnap = await getDoc(subscriptionRef);

    return json({
      success: true,
      message: 'Payment verified and subscription created',
      subscription: subscriptionSnap.data(),
    });
  } catch (err: any) {
    console.error('[razorpay] verify-payment error:', err);
    return json(
      { success: false, error: err.message || 'Payment verification failed' },
      { status: 400 }
    );
  }
}
