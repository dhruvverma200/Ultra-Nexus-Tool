import { json } from '@tanstack/react-start';
import { z } from 'zod';
import crypto from 'crypto';

const RAZORPAY_KEY_ID = process.env.VITE_RAZORPAY_KEY_ID || '';
const RAZORPAY_SECRET_KEY = process.env.RAZORPAY_SECRET_KEY || '';

const createOrderSchema = z.object({
  userId: z.string().min(1),
  planId: z.string().min(1),
  amount: z.number().positive(),
  email: z.string().email(),
});

/**
 * Create Razorpay order
 * POST /api/razorpay/create-order
 */
export async function POST(request: Request) {
  try {
    const data = createOrderSchema.parse(await request.json());

    const response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_SECRET_KEY}`).toString('base64')}`,
      },
      body: JSON.stringify({
        amount: data.amount * 100, // Convert to paise
        currency: 'INR',
        receipt: `${data.userId}-${data.planId}-${Date.now()}`,
        notes: {
          userId: data.userId,
          planId: data.planId,
          email: data.email,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Razorpay API error: ${response.statusText}`);
    }

    const order = await response.json();

    return json({
      orderId: order.id,
      key: RAZORPAY_KEY_ID,
      amount: order.amount,
      currency: order.currency,
    });
  } catch (err: any) {
    console.error('[razorpay] create-order error:', err);
    return json(
      { error: err.message || 'Failed to create order' },
      { status: 400 }
    );
  }
}
