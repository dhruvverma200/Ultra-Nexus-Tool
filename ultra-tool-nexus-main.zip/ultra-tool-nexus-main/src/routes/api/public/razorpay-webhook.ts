import { createFileRoute } from "@tanstack/react-router";

/**
 * Razorpay webhook receiver.
 * URL: https://<your-domain>/api/public/razorpay-webhook
 * Set RAZORPAY_WEBHOOK_SECRET to the same value configured in Razorpay dashboard.
 *
 * Handles:
 *  - payment.captured         → mark subscription active for the period
 *  - subscription.charged     → extend period (autopay renewal)
 *  - subscription.cancelled   → mark cancelled
 *  - refund.processed         → mark refunded
 *
 * Idempotency: each event id is stored in `webhook_events/{id}` and re-deliveries
 * are no-ops.
 */
export const Route = createFileRoute("/api/public/razorpay-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
        const signature = request.headers.get("x-razorpay-signature");
        const body = await request.text();
        if (!secret) return new Response("Webhook secret not configured", { status: 500 });
        if (!signature) return new Response("Missing signature", { status: 400 });

        const { createHmac, timingSafeEqual } = await import("node:crypto");
        const expected = createHmac("sha256", secret).update(body).digest("hex");
        const a = Buffer.from(signature);
        const b = Buffer.from(expected);
        if (a.length !== b.length || !timingSafeEqual(a, b)) {
          return new Response("Invalid signature", { status: 401 });
        }

        const event = JSON.parse(body) as {
          event: string;
          payload: Record<string, { entity: Record<string, unknown> }>;
          id?: string;
        };
        const eventId = event.id ?? request.headers.get("x-razorpay-event-id") ?? `${Date.now()}`;

        try {
          const { getDocument, setDocument, createDocument } = await import(
            "@/lib/firebase-rest.server"
          );
          const { PLANS } = await import("@/lib/razorpay.functions");

          // Idempotency
          const existing = await getDocument(`webhook_events/${eventId}`);
          if (existing) return new Response("ok (duplicate)");

          type Notes = { uid?: string; plan?: string; autopayPlan?: string };
          const payment = event.payload.payment?.entity as
            | { id: string; order_id?: string; notes?: Notes }
            | undefined;
          const subscription = event.payload.subscription?.entity as
            | { id: string; notes?: Notes }
            | undefined;
          const refund = event.payload.refund?.entity as { id: string; payment_id?: string } | undefined;

          const notes = payment?.notes ?? subscription?.notes ?? {};
          const uid = notes.uid;
          const plan = (notes.plan as keyof typeof PLANS | undefined) ?? "pro_monthly";

          if (event.event === "payment.captured" && uid && plan in PLANS) {
            const periodEnd = Date.now() + PLANS[plan].days * 24 * 60 * 60 * 1000;
            await setDocument(
              `subscriptions/${uid}`,
              {
                uid,
                plan,
                status: "active",
                trialUsed: plan === "trial" ? true : undefined,
                currentPeriodEnd: periodEnd,
                autopayPlan: notes.autopayPlan ?? null,
                lastPaymentId: payment?.id ?? null,
                lastOrderId: payment?.order_id ?? null,
                updatedAt: Date.now(),
              },
              { merge: true },
            );
          } else if (event.event === "subscription.charged" && uid && plan in PLANS) {
            const periodEnd = Date.now() + PLANS[plan].days * 24 * 60 * 60 * 1000;
            await setDocument(
              `subscriptions/${uid}`,
              { plan, status: "active", currentPeriodEnd: periodEnd, updatedAt: Date.now() },
              { merge: true },
            );
          } else if (event.event === "subscription.cancelled" && uid) {
            await setDocument(
              `subscriptions/${uid}`,
              { status: "cancelled", updatedAt: Date.now() },
              { merge: true },
            );
          } else if (event.event === "refund.processed" && uid) {
            await setDocument(
              `subscriptions/${uid}`,
              { status: "refunded", updatedAt: Date.now() },
              { merge: true },
            );
          }

          await createDocument("audit_logs", {
            type: `webhook:${event.event}`,
            uid: uid ?? null,
            eventId,
            paymentId: payment?.id ?? refund?.payment_id ?? null,
            at: Date.now(),
          });
          await setDocument(`webhook_events/${eventId}`, { event: event.event, at: Date.now() });
        } catch (e) {
          console.error("[razorpay-webhook] handler error", e);
          // Return 500 so Razorpay retries
          return new Response("handler error", { status: 500 });
        }

        return new Response("ok");
      },
    },
  },
});
