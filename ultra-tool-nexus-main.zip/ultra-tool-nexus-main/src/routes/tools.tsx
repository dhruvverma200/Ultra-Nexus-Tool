import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/tools")({
  component: () => (
    <PageShell>
      <Outlet />
    </PageShell>
  ),
});
