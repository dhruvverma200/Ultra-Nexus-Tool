import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface Item { id: string; toolSlug: string; fileName?: string; createdAt?: { seconds: number } }

export const Route = createFileRoute("/_authenticated/dashboard/history")({
  head: () => ({ meta: [{ title: "History — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: HistoryPage,
});

function HistoryPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<Item[] | null>(null);
  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const q = query(collection(db, "history"), where("uid", "==", user.uid), orderBy("createdAt", "desc"), limit(100));
        const snap = await getDocs(q);
        setItems(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
      } catch { setItems([]); }
    })();
  }, [user]);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">History</h1>
      <p className="mt-1 text-muted-foreground">Your last 100 file operations.</p>
      <div className="mt-6">
        {items === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
          : items.length === 0 ? <Card className="p-10 text-center text-muted-foreground">No activity yet.</Card>
            : <div className="space-y-2">
                {items.map((i) => (
                  <Card key={i.id} className="p-4 flex justify-between items-center">
                    <div>
                      <div className="font-medium text-sm">{i.toolSlug}</div>
                      <div className="text-xs text-muted-foreground">{i.fileName}</div>
                    </div>
                    <div className="text-xs text-muted-foreground">{i.createdAt ? new Date(i.createdAt.seconds * 1000).toLocaleString() : ""}</div>
                  </Card>
                ))}
              </div>}
      </div>
    </div>
  );
}
