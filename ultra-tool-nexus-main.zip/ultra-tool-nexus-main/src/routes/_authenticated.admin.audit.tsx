import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, limit, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/audit")({
  head: () => ({ meta: [{ title: "Audit — Admin" }, { name: "robots", content: "noindex" }] }),
  component: () => {
    const [rows, setRows] = useState<any[] | null>(null);
    useEffect(() => {
      (async () => {
        try {
          const snap = await getDocs(query(collection(db, "audit_logs"), orderBy("createdAt", "desc"), limit(200)));
          setRows(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        } catch { setRows([]); }
      })();
    }, []);
    return (
      <div>
        <h1 className="font-display text-3xl font-bold">Audit log</h1>
        <div className="mt-6">
          {rows === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
            : rows.length === 0 ? <Card className="p-10 text-center text-muted-foreground">No events yet.</Card>
              : <div className="space-y-2">{rows.map((r) => (
                  <Card key={r.id} className="p-3 text-sm flex justify-between"><span>{r.action} · {r.uid}</span><span className="text-xs text-muted-foreground">{r.createdAt ? new Date(r.createdAt).toLocaleString() : ""}</span></Card>
                ))}</div>}
        </div>
      </div>
    );
  },
});
