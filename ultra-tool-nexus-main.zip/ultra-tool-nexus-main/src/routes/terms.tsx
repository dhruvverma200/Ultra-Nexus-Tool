import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';

export const Route = createFileRoute('/terms')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="font-display text-4xl font-bold">Terms of Service</h1>
          <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>

          <Card className="p-8 space-y-6">
            <section>
              <h2 className="font-display text-2xl font-bold">1. Acceptance of Terms</h2>
              <p className="mt-3 text-muted-foreground">
                By using OmniKit, you agree to these terms and our privacy policy. If you disagree, please do not use our service.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">2. User Accounts</h2>
              <p className="mt-3 text-muted-foreground">
                You are responsible for maintaining the confidentiality of your account credentials. You agree to notify us immediately of any unauthorized access.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">3. Acceptable Use</h2>
              <p className="mt-3 text-muted-foreground">
                You agree not to use OmniKit for illegal purposes, harassment, or violating others' rights. We reserve the right to suspend accounts that violate these terms.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">4. Intellectual Property</h2>
              <p className="mt-3 text-muted-foreground">
                OmniKit and all its content are protected by copyright. You may not reproduce, distribute, or transmit our tools without permission.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">5. Limitation of Liability</h2>
              <p className="mt-3 text-muted-foreground">
                OmniKit is provided "as is" without warranties. We are not liable for any indirect damages or losses arising from your use of our service.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">6. Changes to Terms</h2>
              <p className="mt-3 text-muted-foreground">
                We may update these terms at any time. Your continued use of OmniKit constitutes acceptance of the updated terms.
              </p>
            </section>
          </Card>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
