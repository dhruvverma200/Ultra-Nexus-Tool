import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getCountFromServer, getDocs, limit, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/visitors")({
  head: () => ({ meta: [{ title: "Visitors — Admin" }, { name: "robots", content: "noindex" }] }),
  component: VisitorsPage,
});

function VisitorsPage() {
  const [total, setTotal] = useState<number | null>(null);
  const [recent, setRecent] = useState<any[] | null>(null);
  useEffect(() => {
    (async () => {
      try {
        const c = await getCountFromServer(collection(db, "visitors"));
        setTotal(c.data().count);
        const snap = await getDocs(query(collection(db, "visitors"), orderBy("createdAt", "desc"), limit(50)));
        setRecent(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch { setTotal(0); setRecent([]); }
    })();
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Visitor analytics</h1>
      <Card className="mt-6 p-5"><div className="text-xs text-muted-foreground">Total page views</div><div className="mt-1 font-display text-3xl font-bold text-gradient-brand">{total ?? <Loader2 className="h-5 w-5 animate-spin" />}</div></Card>
      <div className="mt-6 space-y-2">
        {recent?.map((r) => (
          <Card key={r.id} className="p-3 text-sm flex justify-between"><span>{r.path}</span><span className="text-xs text-muted-foreground">{r.createdAt ? new Date(r.createdAt).toLocaleString() : ""}</span></Card>
        ))}
      </div>
    </div>
  );
}
