import { createFileRoute, Outlet, Link, useRouterState } from "@tanstack/react-router";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Shield, Users, CreditCard, FileText, Mail, Megaphone, Activity, Eye, Settings } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = [
    { to: "/admin", icon: Shield, label: "Overview" },
    { to: "/admin/users", icon: Users, label: "Users" },
    { to: "/admin/payments", icon: CreditCard, label: "Payments" },
    { to: "/admin/blog", icon: FileText, label: "Blog" },
    { to: "/admin/contact", icon: Mail, label: "Contact" },
    { to: "/admin/ads", icon: Megaphone, label: "Ads" },
    { to: "/admin/audit", icon: Activity, label: "Audit" },
    { to: "/admin/visitors", icon: Eye, label: "Visitors" },
    { to: "/admin/settings", icon: Settings, label: "Settings" },
  ] as const;
  return (
    <ProtectedRoute requireAdmin>
      <div className="container mx-auto px-4 py-10">
        <div className="grid gap-8 md:grid-cols-[220px_1fr]">
          <nav className="space-y-1">
            {items.map((i) => {
              const active = pathname === i.to;
              return (
                <Link key={i.to} to={i.to} className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${active ? "bg-gradient-brand text-brand-foreground shadow-glow" : "hover:bg-accent"}`}>
                  <i.icon className="h-4 w-4" /> {i.label}
                </Link>
              );
            })}
          </nav>
          <div><Outlet /></div>
        </div>
      </div>
    </ProtectedRoute>
  );
}
