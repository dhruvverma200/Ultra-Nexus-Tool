import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { updateProfile } from "firebase/auth";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { doc, updateDoc } from "firebase/firestore";
import { auth, db, storage } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/dashboard/profile")({
  head: () => ({ meta: [{ title: "Profile — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.displayName ?? "");
  const [busy, setBusy] = useState(false);

  async function save() {
    if (!user) return;
    setBusy(true);
    try {
      await updateProfile(user, { displayName: name });
      await updateDoc(doc(db, "users", user.uid), { displayName: name });
      toast.success("Profile updated");
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  }

  async function uploadAvatar(file: File) {
    if (!user) return;
    setBusy(true);
    try {
      const r = ref(storage, `avatars/${user.uid}/${Date.now()}-${file.name}`);
      await uploadBytes(r, file);
      const url = await getDownloadURL(r);
      await updateProfile(user, { photoURL: url });
      await updateDoc(doc(db, "users", user.uid), { photoURL: url });
      toast.success("Avatar updated");
    } catch (e: any) { toast.error(e.message); } finally { setBusy(false); }
  }

  if (!user) return null;
  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-3xl font-bold">Profile</h1>
      <Card className="mt-6 p-6 space-y-5">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src={user.photoURL ?? undefined} />
            <AvatarFallback className="bg-gradient-brand text-brand-foreground">{(user.email ?? "U")[0].toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <input id="avatar" type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadAvatar(f); }} />
            <Button asChild variant="outline" size="sm"><label htmlFor="avatar" className="cursor-pointer">Change avatar</label></Button>
          </div>
        </div>
        <div><Label>Email</Label><Input value={user.email ?? ""} disabled /></div>
        <div><Label>Display name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
        <Button onClick={save} disabled={busy} className="bg-gradient-brand text-brand-foreground">Save changes</Button>
      </Card>
    </div>
  );
}
