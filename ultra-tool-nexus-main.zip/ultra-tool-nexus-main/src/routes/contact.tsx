import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useState } from 'react';
import { toast } from 'sonner';
import { Loader2, Mail, MessageSquare } from 'lucide-react';

export const Route = createFileRoute('/contact')(() => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      // TODO: Implement contact form submission
      await new Promise((resolve) => setTimeout(resolve, 1000));
      toast.success('Message sent! We\'ll get back to you soon.');
      setName('');
      setEmail('');
      setMessage('');
    } catch (err: any) {
      toast.error(err.message || 'Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-brand text-brand-foreground shadow-glow mb-4">
              <MessageSquare className="h-6 w-6" />
            </div>
            <h1 className="font-display text-4xl font-bold">Contact Us</h1>
            <p className="mt-3 text-muted-foreground">Have questions? We'd love to hear from you.</p>
          </div>

          <Card className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us what's on your mind..."
                  required
                  className="min-h-32"
                />
              </div>

              <Button type="submit" disabled={loading} className="w-full bg-gradient-brand text-brand-foreground">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Send message
              </Button>
            </form>
          </Card>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              {
                icon: Mail,
                title: 'Email',
                value: 'support@omnikit.com',
                href: 'mailto:support@omnikit.com',
              },
              {
                icon: MessageSquare,
                title: 'Discord',
                value: 'Join our community',
                href: '#',
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <Card key={item.title} className="p-6 text-center">
                  <Icon className="mx-auto h-8 w-8 text-brand mb-3" />
                  <h3 className="font-display font-semibold">{item.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{item.value}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
