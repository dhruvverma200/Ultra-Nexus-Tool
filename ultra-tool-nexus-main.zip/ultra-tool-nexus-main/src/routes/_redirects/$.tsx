import { createFileRoute } from '@tanstack/react-router';
import { useNavigate } from '@tanstack/react-router';
import { useEffect } from 'react';

export const Route = createFileRoute('/_redirects/$')(({
  params,
}) => {
  const navigate = useNavigate();

  useEffect(() => {
    navigate({ to: '/404' });
  }, [navigate, params]);

  return null;
});
