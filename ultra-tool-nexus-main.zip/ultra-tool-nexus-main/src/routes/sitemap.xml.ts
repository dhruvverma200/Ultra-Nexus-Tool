import { createFileRoute } from "@tanstack/react-router";
import { TOOLS } from "@/lib/tools";

export const Route = createFileRoute("/sitemap/xml")({
  server: {
    handlers: {
      GET: () => {
        const base = "https://omnikit.app";
        const staticPaths = ["", "/tools", "/pricing", "/blog", "/about", "/contact", "/privacy", "/terms"];
        const urls = [
          ...staticPaths.map((p) => `${base}${p}`),
          ...TOOLS.map((t) => `${base}/tools/${t.slug}`),
        ];
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${u}</loc></url>`).join("\n")}\n</urlset>`;
        return new Response(xml, { headers: { "content-type": "application/xml" } });
      },
    },
  },
});
