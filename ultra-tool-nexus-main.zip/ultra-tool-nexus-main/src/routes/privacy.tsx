import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';

export const Route = createFileRoute('/privacy')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto space-y-8">
          <h1 className="font-display text-4xl font-bold">Privacy Policy</h1>
          <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>

          <Card className="p-8 space-y-6">
            <section>
              <h2 className="font-display text-2xl font-bold">1. Data Collection</h2>
              <p className="mt-3 text-muted-foreground">
                We minimize data collection. Most tools process data locally in your browser without uploading to our servers.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">2. File Storage</h2>
              <p className="mt-3 text-muted-foreground">
                When tools require file uploads, we store them temporarily and delete them within 1 hour. We never retain or sell your data.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">3. Analytics</h2>
              <p className="mt-3 text-muted-foreground">
                We use basic analytics to understand usage patterns. We do not track individual users or use tracking pixels.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">4. Security</h2>
              <p className="mt-3 text-muted-foreground">
                All communications are encrypted over HTTPS. Your account data is secured with industry-standard encryption.
              </p>
            </section>

            <section>
              <h2 className="font-display text-2xl font-bold">5. Your Rights</h2>
              <p className="mt-3 text-muted-foreground">
                You can request to delete your account and associated data anytime. Email us for assistance.
              </p>
            </section>
          </Card>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
