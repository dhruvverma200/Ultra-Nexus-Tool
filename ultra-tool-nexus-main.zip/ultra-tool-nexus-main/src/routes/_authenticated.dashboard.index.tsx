import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { TOOLS } from "@/lib/tools";
import { ToolCard } from "@/components/ToolCard";
import { Card } from "@/components/ui/card";
import { Wrench, History, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/")({
  head: () => ({ meta: [{ title: "Dashboard — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: DashboardHome,
});

function DashboardHome() {
  const { user } = useAuth();
  const featured = TOOLS.filter((t) => t.implemented).slice(0, 6);
  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold">Welcome back{user?.displayName ? `, ${user.displayName.split(" ")[0]}` : ""}</h1>
        <p className="mt-1 text-muted-foreground">Pick up where you left off.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-5"><div className="flex items-center gap-2 text-muted-foreground text-sm"><Wrench className="h-4 w-4" /> Tools used today</div><div className="mt-1 font-display text-3xl font-bold text-gradient-brand">0</div></Card>
        <Card className="p-5"><div className="flex items-center gap-2 text-muted-foreground text-sm"><History className="h-4 w-4" /> Files processed</div><div className="mt-1 font-display text-3xl font-bold text-gradient-brand">0</div></Card>
        <Card className="p-5"><div className="flex items-center gap-2 text-muted-foreground text-sm"><Sparkles className="h-4 w-4" /> Plan</div><div className="mt-1 font-display text-2xl font-bold">Free</div><Link to="/dashboard/subscription" className="text-xs text-brand hover:underline">Upgrade →</Link></Card>
      </div>
      <div>
        <h2 className="font-display text-xl font-semibold">Quick tools</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((t) => <ToolCard key={t.slug} tool={t} />)}
        </div>
      </div>
    </div>
  );
}
