import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  head: () => ({ meta: [{ title: "Settings — Admin" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <div>
      <h1 className="font-display text-3xl font-bold">App settings</h1>
      <Card className="mt-6 p-6 space-y-3 text-sm text-muted-foreground">
        <p>Environment variables drive the app config. Edit <code>.env</code> to update Firebase or Razorpay keys, then redeploy.</p>
        <p>To deploy security rules: <code>firebase deploy --only firestore:rules,storage</code>.</p>
      </Card>
    </div>
  ),
});
