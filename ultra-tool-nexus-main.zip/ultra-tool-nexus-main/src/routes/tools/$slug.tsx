import { createFileRoute } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

export const Route = createFileRoute('/tools/$slug')(() => {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    // Redirect to tools list if slug is not found
    if (!slug) {
      navigate({ to: '/tools' });
    }
  }, [slug, navigate]);

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <Card className="p-8 max-w-md mx-auto text-center">
          <AlertCircle className="mx-auto h-8 w-8 text-muted-foreground mb-3" />
          <h1 className="font-display text-lg font-semibold">Tool not found</h1>
          <p className="mt-2 text-sm text-muted-foreground">The tool you're looking for doesn't exist yet.</p>
        </Card>
      </div>
    </PageShell>
  );
});

export default Route.component;
