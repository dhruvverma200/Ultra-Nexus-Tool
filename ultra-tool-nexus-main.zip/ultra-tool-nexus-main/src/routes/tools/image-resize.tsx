import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { useState, useRef } from 'react';
import { toast } from 'sonner';
import { Download, Upload, Loader2 } from 'lucide-react';

export const Route = createFileRoute('/tools/image-compress')(() => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [quality, setQuality] = useState(80);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCompress = async () => {
    if (!file) {
      toast.error('Please select an image');
      return;
    }

    setLoading(true);
    try {
      const img = new Image();
      const url = URL.createObjectURL(file);

      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Failed to get canvas context');

        ctx.drawImage(img, 0, 0);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              const originalSize = (file.size / 1024 / 1024).toFixed(2);
              const compressedSize = (blob.size / 1024 / 1024).toFixed(2);
              const savings = (((file.size - blob.size) / file.size) * 100).toFixed(1);

              const a = document.createElement('a');
              a.href = URL.createObjectURL(blob);
              a.download = `compressed-${file.name}`;
              a.click();
              URL.revokeObjectURL(a.href);

              toast.success(`Saved ${savings}% space (${originalSize}MB → ${compressedSize}MB)`);
              setFile(null);
            }
          },
          'image/jpeg',
          quality / 100
        );
        URL.revokeObjectURL(url);
      };

      img.onerror = () => {
        toast.error('Failed to load image');
      };

      img.src = url;
    } catch (err: any) {
      toast.error(err.message || 'Failed to compress image');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl font-bold">Compress Image</h1>
          <p className="mt-2 text-muted-foreground">Reduce file size while keeping quality</p>

          <Card className="mt-8 p-8">
            <div className="space-y-6">
              {/* Upload Area */}
              <div
                className="border-2 border-dashed border-border/60 rounded-lg p-8 text-center cursor-pointer hover:bg-muted/50 transition"
                onDrop={(e) => {
                  e.preventDefault();
                  const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith('image/'));
                  if (files.length > 0) setFile(files[0]);
                }}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-3" />
                <h3 className="font-display font-semibold">Drop image here</h3>
                <p className="text-sm text-muted-foreground mt-1">or click to browse</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) setFile(f);
                  }}
                />
              </div>

              {file && (
                <>
                  <div className="p-3 bg-muted rounded">
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Quality: {quality}%</Label>
                    <Input
                      type="range"
                      min="1"
                      max="100"
                      value={quality}
                      onChange={(e) => setQuality(Number(e.target.value))}
                    />
                  </div>
                </>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleCompress}
                  disabled={loading || !file}
                  className="flex-1 bg-gradient-brand text-brand-foreground"
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Compress
                </Button>
                {file && (
                  <Button
                    variant="outline"
                    onClick={() => setFile(null)}
                    disabled={loading}
                  >
                    Clear
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
