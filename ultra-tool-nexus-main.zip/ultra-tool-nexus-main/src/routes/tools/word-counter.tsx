import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { useState } from 'react';
import { toast } from 'sonner';
import { Copy, Check } from 'lucide-react';

type Case = 'upper' | 'lower' | 'title' | 'sentence' | 'toggle';

export const Route = createFileRoute('/tools/word-counter')(() => {
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);

  const stats = {
    words: text.trim().split(/\s+/).filter(Boolean).length,
    characters: text.length,
    charactersNoSpaces: text.replace(/\s/g, '').length,
    sentences: text.split(/[.!?]+/).filter(Boolean).length,
    paragraphs: text.split(/\n\n+/).filter(Boolean).length,
    readingTime: Math.ceil(text.trim().split(/\s+/).filter(Boolean).length / 200),
  };

  const handleCopy = (value: number) => {
    navigator.clipboard.writeText(value.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Copied!');
  };

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-4xl">
          <h1 className="font-display text-3xl font-bold">Word Counter</h1>
          <p className="mt-2 text-muted-foreground">Analyze text: words, characters, sentences and more</p>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Label>Your text</Label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste or type your text here..."
                className="mt-2 w-full h-96 p-4 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none"
              />
            </div>

            <div className="space-y-3">
              {[
                { label: 'Words', value: stats.words },
                { label: 'Characters', value: stats.characters },
                { label: 'Chars (no spaces)', value: stats.charactersNoSpaces },
                { label: 'Sentences', value: stats.sentences },
                { label: 'Paragraphs', value: stats.paragraphs },
                { label: 'Reading time (min)', value: stats.readingTime },
              ].map((stat) => (
                <Card key={stat.label} className="p-4">
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <div className="flex items-center justify-between mt-2">
                    <p className="font-display text-2xl font-bold text-gradient-brand">{stat.value}</p>
                    <button
                      onClick={() => handleCopy(stat.value)}
                      className="p-1.5 hover:bg-muted rounded transition"
                    >
                      {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4 text-muted-foreground" />}
                    </button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
