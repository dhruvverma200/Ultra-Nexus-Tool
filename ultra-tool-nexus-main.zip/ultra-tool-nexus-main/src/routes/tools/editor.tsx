import { createFileRoute, Link } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CheckCircle2, XCircle } from 'lucide-react';

export const Route = createFileRoute('/tools/editor')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <Card className="p-8 max-w-md mx-auto text-center">
          <div className="mx-auto h-12 w-12 bg-muted rounded-lg flex items-center justify-center mb-4">
            <CheckCircle2 className="h-8 w-8 text-muted-foreground" />
          </div>
          <h1 className="font-display text-lg font-semibold">Tool Editor</h1>
          <p className="mt-2 text-sm text-muted-foreground">Premium editor tools coming soon.</p>
          <Button asChild className="mt-4" variant="outline">
            <Link to="/tools">Back to tools</Link>
          </Button>
        </Card>
      </div>
    </PageShell>
  );
});

export default Route.component;
