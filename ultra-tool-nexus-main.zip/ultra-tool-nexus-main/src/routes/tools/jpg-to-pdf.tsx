import { createFileRoute } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { useState, useRef } from 'react';
import { toast } from 'sonner';
import { Download, Upload, Loader2 } from 'lucide-react';
import { PDFDocument, PDFPage } from 'pdf-lib';

export const Route = createFileRoute('/tools/jpg-to-pdf')(() => {
  const { user } = useAuth();
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (newFiles: File[]) => {
    const imageFiles = newFiles.filter((f) => f.type.startsWith('image/'));
    if (imageFiles.length === 0) {
      toast.error('Please select image files (JPG, PNG, WebP, etc.)');
      return;
    }
    setFiles([...files, ...imageFiles]);
    toast.success(`Added ${imageFiles.length} image(s)`);
  };

  const handleConvert = async () => {
    if (files.length === 0) {
      toast.error('Please select at least one image');
      return;
    }

    setLoading(true);
    try {
      const pdfDoc = await PDFDocument.create();

      for (const file of files) {
        const data = await file.arrayBuffer();
        let image;

        if (file.type === 'image/jpeg') {
          image = await pdfDoc.embedJpg(data);
        } else if (file.type === 'image/png') {
          image = await pdfDoc.embedPng(data);
        } else {
          // For other formats, try as PNG
          image = await pdfDoc.embedPng(data);
        }

        const page = pdfDoc.addPage([image.width, image.height]);
        page.drawImage(image, {
          x: 0,
          y: 0,
          width: image.width,
          height: image.height,
        });
      }

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'converted.pdf';
      a.click();
      URL.revokeObjectURL(url);

      toast.success('PDF created successfully');
      setFiles([]);
    } catch (err: any) {
      toast.error(err.message || 'Failed to convert images');
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl font-bold">JPG to PDF</h1>
          <p className="mt-2 text-muted-foreground">Convert images to PDF in seconds</p>

          <Card className="mt-8 p-8">
            <div className="space-y-6">
              {/* Upload Area */}
              <div
                className="border-2 border-dashed border-border/60 rounded-lg p-8 text-center cursor-pointer hover:bg-muted/50 transition"
                onDrop={(e) => {
                  e.preventDefault();
                  handleFileSelect(Array.from(e.dataTransfer.files));
                }}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-3" />
                <h3 className="font-display font-semibold">Drop images here</h3>
                <p className="text-sm text-muted-foreground mt-1">or click to browse</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleFileSelect(Array.from(e.target.files || []))}
                />
              </div>

              {/* File List */}
              {files.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-display font-semibold">Selected images ({files.length})</h3>
                  <div className="space-y-1">
                    {files.map((file, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-muted rounded">
                        <span className="text-sm truncate">{file.name}</span>
                        <button
                          onClick={() => setFiles(files.filter((_, idx) => idx !== i))}
                          className="text-xs text-destructive hover:underline"
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleConvert}
                  disabled={loading || files.length === 0}
                  className="flex-1 bg-gradient-brand text-brand-foreground"
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Convert to PDF
                </Button>
                {files.length > 0 && (
                  <Button
                    variant="outline"
                    onClick={() => setFiles([])}
                    disabled={loading}
                  >
                    Clear all
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
