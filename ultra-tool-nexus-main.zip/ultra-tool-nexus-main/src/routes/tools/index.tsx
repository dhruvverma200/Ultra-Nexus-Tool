import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { TOOLS, getToolsByCategory } from "@/lib/tools";
import { ToolCard } from "@/components/ToolCard";
import { Search, Zap } from "lucide-react";
import { useState, useMemo } from "react";

export const Route = createFileRoute("/tools/")(() => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredTools = useMemo(() => {
    let result = selectedCategory ? getToolsByCategory(selectedCategory as any) : TOOLS;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (t) =>
          t.name.toLowerCase().includes(query) ||
          t.description.toLowerCase().includes(query)
      );
    }

    return result;
  }, [searchQuery, selectedCategory]);

  return (
    <PageShell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/60">
        <div className="absolute inset-0 bg-aurora opacity-70" aria-hidden />
        <div className="container relative mx-auto px-4 py-16 text-center">
          <h1 className="font-display text-4xl md:text-5xl font-bold">All 100+ tools</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Search and browse all premium tools available on OmniKit.
          </p>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="search">Search tools</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="search"
                placeholder="PDF, image, text, code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Categories</Label>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => setSelectedCategory(null)}
              >
                All tools ({TOOLS.length})
              </Button>
              {[
                { id: "pdf", label: "PDF" },
                { id: "image", label: "Images" },
                { id: "media", label: "Media" },
                { id: "text", label: "Text" },
                { id: "developer", label: "Developer" },
                { id: "calculator", label: "Calculators" },
                { id: "utility", label: "Utilities" },
              ].map((cat) => {
                const count = getToolsByCategory(cat.id as any).length;
                return (
                  <Button
                    key={cat.id}
                    variant={selectedCategory === cat.id ? "default" : "outline"}
                    onClick={() => setSelectedCategory(cat.id)}
                  >
                    {cat.label} ({count})
                  </Button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="container mx-auto px-4 py-10">
        {filteredTools.length === 0 ? (
          <div className="text-center py-10">
            <Card className="p-8 max-w-md mx-auto">
              <Zap className="mx-auto h-8 w-8 text-muted-foreground mb-3" />
              <h3 className="font-display text-lg font-semibold">No tools found</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Try adjusting your search or filters.
              </p>
              <Button
                variant="ghost"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory(null);
                }}
                className="mt-4"
              >
                Clear filters
              </Button>
            </Card>
          </div>
        ) : (
          <>
            <div className="mb-6 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing <span className="font-semibold text-foreground">{filteredTools.length}</span> of{" "}
                <span className="font-semibold text-foreground">{TOOLS.length}</span> tools
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {filteredTools.map((tool) => (
                <ToolCard key={tool.slug} tool={tool} />
              ))}
            </div>
          </>
        )}
      </section>
    </PageShell>
  );
});

export default Route.component;
