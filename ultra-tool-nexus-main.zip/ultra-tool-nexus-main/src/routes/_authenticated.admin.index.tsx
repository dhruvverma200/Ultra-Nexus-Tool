import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({ meta: [{ title: "Admin — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <div>
      <h1 className="font-display text-3xl font-bold">Admin overview</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {["Users", "Active subs", "Today's events"].map((l) => (
          <Card key={l} className="p-5">
            <div className="text-xs text-muted-foreground">{l}</div>
            <div className="mt-1 font-display text-3xl font-bold text-gradient-brand">—</div>
          </Card>
        ))}
      </div>
    </div>
  ),
});
