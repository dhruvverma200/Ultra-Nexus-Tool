import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { getToolBySlug, TOOLS } from "@/lib/tools";
import { ToolRunner } from "@/components/tools/ToolRunner";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/tools/$slug")({
  loader: ({ params }) => {
    const tool = getToolBySlug(params.slug);
    if (!tool) throw notFound();
    // If this slug is actually an editor mode, redirect handled in component via Link.
    return { tool };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.tool.name} — OmniKit` },
      { name: "description", content: loaderData?.tool.description },
      { property: "og:title", content: `${loaderData?.tool.name} — OmniKit` },
      { property: "og:description", content: loaderData?.tool.description },
    ],
    links: [{ rel: "canonical", href: `/tools/${loaderData?.tool.slug}` }],
  }),
  notFoundComponent: ToolNotFound,
  component: ToolPage,
});

function ToolNotFound() {
  return (
    <div className="container mx-auto px-4 py-20 text-center">
      <h1 className="font-display text-3xl font-bold">Tool not found</h1>
      <p className="mt-2 text-muted-foreground">That tool doesn't exist (yet).</p>
      <Button asChild className="mt-6"><Link to="/tools">Browse all tools</Link></Button>
    </div>
  );
}

function ToolPage() {
  const { tool } = Route.useLoaderData();
  // Sibling tools from same category for the "Related" rail
  const related = TOOLS.filter((t) => t.category === tool.category && t.slug !== tool.slug).slice(0, 6);

  return (
    <div className="container mx-auto px-4 py-10">
      <Link to="/tools" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All tools
      </Link>
      <div className="mt-4 flex flex-col gap-2">
        <h1 className="font-display text-3xl md:text-4xl font-bold">{tool.name}</h1>
        <p className="text-muted-foreground max-w-2xl">{tool.description}</p>
      </div>

      <div className="mt-8">
        <ToolRunner tool={tool} />
      </div>

      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="font-display text-xl font-semibold">Related tools</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((r) => (
              <Link key={r.slug} to="/tools/$slug" params={{ slug: r.slug }} className="rounded-xl border border-border bg-card p-4 text-sm hover:border-brand/50 hover:shadow-glow transition">
                <div className="font-medium">{r.name}</div>
                <div className="mt-0.5 text-xs text-muted-foreground line-clamp-1">{r.description}</div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
