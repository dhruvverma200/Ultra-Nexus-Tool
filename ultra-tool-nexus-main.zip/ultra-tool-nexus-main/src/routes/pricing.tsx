import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check, Sparkles, Star } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — OmniKit" },
      { name: "description", content: "Pick the plan that fits. ₹1 trial, generous free tier, Pro monthly and best-value annual." },
      { property: "og:title", content: "Pricing — OmniKit" },
      { property: "og:description", content: "Premium tools, fair pricing. Start free or grab the ₹1 trial." },
    ],
    links: [{ rel: "canonical", href: "/pricing" }],
  }),
  component: Pricing,
});

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: "₹0",
    period: "forever",
    cta: "Get started",
    highlight: false,
    features: ["20 ops/day per tool", "All 100+ tools", "Basic support", "No watermarks"],
  },
  {
    id: "trial",
    name: "₹1 Trial",
    price: "₹1",
    period: "7 days, first time only",
    cta: "Try for ₹1",
    highlight: false,
    tag: "Best to test",
    features: ["All Pro features unlocked", "Unlimited usage", "Priority support", "Cancel anytime"],
  },
  {
    id: "pro_monthly",
    name: "Pro Monthly",
    price: "₹299",
    period: "per month",
    cta: "Go Pro",
    highlight: false,
    features: ["Unlimited usage", "All Pro tools", "Priority support", "Cancel anytime"],
  },
  {
    id: "pro_annual",
    name: "Pro Annual",
    price: "₹2,499",
    period: "per year",
    cta: "Save 30%",
    highlight: true,
    tag: "Best value",
    features: ["Everything in Pro Monthly", "30% saving vs monthly", "Early access to features", "Dedicated support"],
  },
];

function Pricing() {
  return (
    <PageShell>
      <section className="relative overflow-hidden border-b border-border/60">
        <div className="absolute inset-0 bg-aurora opacity-70" aria-hidden />
        <div className="container relative mx-auto px-4 py-20 text-center">
          <h1 className="font-display text-4xl md:text-5xl font-bold">Simple, fair pricing</h1>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">Start free. Unlock everything for ₹1. Cancel anytime.</p>
        </div>
      </section>

      <section className="container mx-auto px-4 py-14">
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {PLANS.map((p) => (
            <Card key={p.id} className={`relative p-6 flex flex-col ${p.highlight ? "border-brand shadow-glow" : ""}`}>
              {p.tag && (
                <span className="absolute -top-2 left-6 inline-flex items-center gap-1 rounded-full bg-gradient-brand text-brand-foreground px-2 py-0.5 text-[10px] font-medium">
                  <Star className="h-3 w-3" /> {p.tag}
                </span>
              )}
              <div className="font-display text-lg font-semibold">{p.name}</div>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-4xl font-bold text-gradient-brand">{p.price}</span>
              </div>
              <div className="text-xs text-muted-foreground">{p.period}</div>
              <ul className="mt-5 space-y-2 text-sm flex-1">
                {p.features.map((f) => (
                  <li key={f} className="flex gap-2">
                    <Check className="h-4 w-4 text-success shrink-0 mt-0.5" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Button
                asChild
                className={`mt-6 ${p.highlight ? "bg-gradient-brand text-brand-foreground" : ""}`}
                variant={p.highlight ? "default" : "outline"}
              >
                <Link to="/dashboard/subscription">{p.cta}</Link>
              </Button>
            </Card>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-4 py-12">
        <h2 className="font-display text-2xl font-bold text-center">Feature comparison</h2>
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-3">Feature</th>
                <th className="py-3 px-3">Free</th>
                <th className="py-3 px-3">Trial</th>
                <th className="py-3 px-3">Pro Monthly</th>
                <th className="py-3 px-3">Pro Annual</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["All 100+ tools", "✓", "✓", "✓", "✓"],
                ["Daily quota", "20 / tool", "Unlimited", "Unlimited", "Unlimited"],
                ["No watermarks", "✓", "✓", "✓", "✓"],
                ["Priority queue", "—", "✓", "✓", "✓"],
                ["Early access", "—", "—", "—", "✓"],
                ["Dedicated support", "—", "—", "—", "✓"],
              ].map((row, i) => (
                <tr key={i} className="border-b border-border/60">
                  {row.map((c, j) => (
                    <td key={j} className={`py-3 px-3 ${j === 0 ? "text-left font-medium" : "text-center text-muted-foreground"}`}>
                      {c}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="container mx-auto px-4 py-12 max-w-2xl">
        <h2 className="text-center font-display text-2xl font-bold">Questions, answered</h2>
        <Accordion type="single" collapsible className="mt-6">
          {[
            {
              q: "How does the ₹1 trial work?",
              a: "First-time only. You pay ₹1, get all Pro features unlocked for 7 days, and your chosen plan starts billing automatically after day 3 unless you cancel.",
            },
            {
              q: "Can I cancel?",
              a: "Yes, from your dashboard, anytime. We don't pull stunts.",
            },
            {
              q: "Do you offer refunds?",
              a: "We refund within 7 days, no questions asked. Email us from your account.",
            },
            {
              q: "Is there a student discount?",
              a: "Yes — email us with proof and we'll send you a code.",
            },
          ].map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left font-medium">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      <section className="container mx-auto px-4 pb-20">
        <div className="rounded-3xl border bg-gradient-brand text-brand-foreground p-10 text-center shadow-glow">
          <Sparkles className="mx-auto h-8 w-8" />
          <h2 className="mt-3 font-display text-3xl font-bold">Try Pro for ₹1</h2>
          <p className="mt-2 opacity-90">Unlock the entire OmniKit toolkit for a week.</p>
          <Button asChild size="lg" variant="secondary" className="mt-5">
            <Link to="/dashboard/subscription">Start ₹1 trial</Link>
          </Button>
        </div>
      </section>
    </PageShell>
  );
}
