import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { startRazorpayCheckout } from "@/lib/razorpay";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Loader2, Sparkles, Check } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Subscription {
  uid: string;
  plan: "free" | "trial" | "pro_monthly" | "pro_annual";
  status: "active" | "cancelled" | "expired";
  trialUsed: boolean;
  currentPeriodEnd?: number;
  autopayPlan?: "pro_monthly" | "pro_annual";
}

export const Route = createFileRoute("/_authenticated/dashboard/subscription")({
  head: () => ({ meta: [{ title: "Subscription — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: SubscriptionPage,
});

function SubscriptionPage() {
  const { user } = useAuth();
  const [sub, setSub] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [autopay, setAutopay] = useState<"pro_monthly" | "pro_annual">("pro_monthly");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const snap = await getDoc(doc(db, "subscriptions", user.uid));
      setSub(snap.exists() ? (snap.data() as Subscription) : { uid: user.uid, plan: "free", status: "active", trialUsed: false });
      setLoading(false);
    })();
  }, [user]);

  async function startTrial() {
    if (!user || !sub) return;
    if (sub.trialUsed) { toast.error("Trial already used on this account"); return; }
    setBusy(true);
    try {
      const result = await startRazorpayCheckout({
        uid: user.uid,
        plan: "trial",
        autopayPlan: autopay,
        description: "OmniKit ₹1 Trial (7 days)",
        userEmail: user.email ?? undefined,
        userName: user.displayName ?? undefined,
      });
      // Fallback client-side write in case the server-side persist failed
      // (e.g. FIREBASE_SERVICE_ACCOUNT_JSON missing). Firestore rules still gate it.
      await setDoc(doc(db, "subscriptions", user.uid), {
        uid: user.uid,
        plan: "trial",
        status: "active",
        trialUsed: true,
        currentPeriodEnd: result.currentPeriodEnd,
        autopayPlan: autopay,
        lastPaymentId: result.paymentId,
        updatedAt: Date.now(),
      }, { merge: true });
      setSub({ uid: user.uid, plan: "trial", status: "active", trialUsed: true, currentPeriodEnd: result.currentPeriodEnd, autopayPlan: autopay });
      toast.success("₹1 trial activated for 7 days");
    } catch (e: any) {
      toast.error(e?.message ?? "Payment cancelled");
    } finally { setBusy(false); }
  }

  async function buyPlan(plan: "pro_monthly" | "pro_annual") {
    if (!user) return;
    setBusy(true);
    try {
      const result = await startRazorpayCheckout({
        uid: user.uid,
        plan,
        description: `OmniKit ${plan === "pro_monthly" ? "Pro Monthly" : "Pro Annual"}`,
        userEmail: user.email ?? undefined,
        userName: user.displayName ?? undefined,
      });
      await setDoc(doc(db, "subscriptions", user.uid), {
        uid: user.uid, plan, status: "active", trialUsed: sub?.trialUsed ?? false,
        currentPeriodEnd: result.currentPeriodEnd, lastPaymentId: result.paymentId, updatedAt: Date.now(),
      }, { merge: true });
      toast.success("Subscription active");
      setSub((s) => ({ ...(s as Subscription), plan, status: "active", currentPeriodEnd: result.currentPeriodEnd }));
    } catch (e: any) { toast.error(e?.message ?? "Payment cancelled"); }
    finally { setBusy(false); }
  }

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>;

  return (
    <div className="max-w-3xl space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold">Subscription</h1>
        <p className="mt-1 text-muted-foreground">Manage your plan and billing.</p>
      </div>

      <Card className="p-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wide">Current plan</div>
            <div className="mt-1 font-display text-2xl font-bold text-gradient-brand">{labelFor(sub?.plan ?? "free")}</div>
            {sub?.currentPeriodEnd && <div className="mt-1 text-xs text-muted-foreground">Renews / ends {new Date(sub.currentPeriodEnd).toLocaleDateString()}</div>}
          </div>
          <span className={`rounded-full px-3 py-1 text-xs font-medium ${sub?.status === "active" ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>{sub?.status ?? "active"}</span>
        </div>
      </Card>

      {/* TRIAL CARD */}
      {!sub?.trialUsed && sub?.plan === "free" && (
        <Card className="p-6 border-brand shadow-glow">
          <div className="flex items-center gap-2 text-brand"><Sparkles className="h-5 w-5" /><span className="font-display text-lg font-semibold">₹1 Trial — 7 days, all features</span></div>
          <p className="mt-2 text-sm text-muted-foreground">Auto-converts to your chosen plan after day 3 unless cancelled. First-time only.</p>
          <div className="mt-4 flex items-end gap-3">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground">Plan after trial</label>
              <Select value={autopay} onValueChange={(v) => setAutopay(v as any)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pro_monthly">Pro Monthly · ₹299/mo</SelectItem>
                  <SelectItem value="pro_annual">Pro Annual · ₹2,499/yr</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={startTrial} disabled={busy} className="bg-gradient-brand text-brand-foreground">Start ₹1 trial</Button>
          </div>
        </Card>
      )}

      {/* PLAN GRID */}
      <div className="grid gap-4 md:grid-cols-2">
        <PlanCard title="Pro Monthly" price="₹299/mo" features={["Unlimited usage", "All tools", "Priority support"]} active={sub?.plan === "pro_monthly"} busy={busy} onBuy={() => buyPlan("pro_monthly")} />
        <PlanCard title="Pro Annual" price="₹2,499/yr" tag="Best value" features={["Unlimited usage", "All tools", "Early access", "Save 30%"]} active={sub?.plan === "pro_annual"} busy={busy} onBuy={() => buyPlan("pro_annual")} />
      </div>
    </div>
  );
}

function labelFor(p: string) {
  return ({ free: "Free", trial: "₹1 Trial", pro_monthly: "Pro Monthly", pro_annual: "Pro Annual" } as Record<string, string>)[p] ?? p;
}

function PlanCard({ title, price, features, tag, active, busy, onBuy }: { title: string; price: string; features: string[]; tag?: string; active?: boolean; busy?: boolean; onBuy: () => void }) {
  return (
    <Card className={`p-6 ${tag ? "border-brand" : ""}`}>
      <div className="flex items-baseline justify-between">
        <div className="font-display text-lg font-semibold">{title}</div>
        {tag && <span className="rounded-full bg-brand/10 text-brand px-2 py-0.5 text-[10px] font-medium">{tag}</span>}
      </div>
      <div className="mt-1 font-display text-2xl font-bold text-gradient-brand">{price}</div>
      <ul className="mt-4 space-y-1.5 text-sm">
        {features.map((f) => <li key={f} className="flex gap-2"><Check className="h-4 w-4 text-success mt-0.5" />{f}</li>)}
      </ul>
      <Button onClick={onBuy} disabled={busy || active} className="mt-5 w-full bg-gradient-brand text-brand-foreground">
        {active ? "Current plan" : "Upgrade"}
      </Button>
    </Card>
  );
}
