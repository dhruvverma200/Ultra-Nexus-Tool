import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';

export const Route = createFileRoute('/blog')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <div className="text-center">
          <h1 className="font-display text-4xl font-bold">Blog</h1>
          <p className="mt-3 text-muted-foreground">Coming soon</p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="p-6 animate-pulse">
              <div className="h-4 w-3/4 bg-muted rounded mb-4" />
              <div className="h-3 w-full bg-muted rounded mb-2" />
              <div className="h-3 w-5/6 bg-muted rounded" />
            </Card>
          ))}
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
