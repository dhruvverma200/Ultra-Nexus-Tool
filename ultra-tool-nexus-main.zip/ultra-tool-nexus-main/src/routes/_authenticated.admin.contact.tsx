import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, orderBy, query } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/contact")({
  head: () => ({ meta: [{ title: "Contact — Admin" }, { name: "robots", content: "noindex" }] }),
  component: ContactAdmin,
});

function ContactAdmin() {
  const [rows, setRows] = useState<any[] | null>(null);
  useEffect(() => {
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, "contact_submissions"), orderBy("createdAt", "desc")));
        setRows(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } catch { setRows([]); }
    })();
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Contact submissions</h1>
      <div className="mt-6">
        {rows === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
          : rows.length === 0 ? <Card className="p-10 text-center text-muted-foreground">No submissions yet.</Card>
            : <div className="space-y-2">
                {rows.map((r) => (
                  <Card key={r.id} className="p-4">
                    <div className="flex justify-between"><div className="font-medium text-sm">{r.name} · {r.email}</div><div className="text-xs text-muted-foreground">{r.createdAt ? new Date(r.createdAt).toLocaleString() : ""}</div></div>
                    <div className="mt-1 text-sm whitespace-pre-wrap">{r.message}</div>
                  </Card>
                ))}
              </div>}
      </div>
    </div>
  );
}
