import { createFileRoute } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { PageShell } from '@/components/PageShell';
import { useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';

export const Route = createFileRoute('/dashboard')(() => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: '/auth', search: { redirect: '/dashboard' } });
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <PageShell>
        <div className="container mx-auto px-4 py-10">
          <div className="h-64 bg-card rounded-2xl border border-border/60 animate-pulse" />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          {/* Subscription card */}
          <div className="rounded-2xl border border-border/60 bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Your subscription</h2>
            <p className="mt-2 text-sm text-muted-foreground">Manage your plan and billing</p>
          </div>
          {/* Usage card */}
          <div className="rounded-2xl border border-border/60 bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Usage</h2>
            <p className="mt-2 text-sm text-muted-foreground">View your tool usage and quotas</p>
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
