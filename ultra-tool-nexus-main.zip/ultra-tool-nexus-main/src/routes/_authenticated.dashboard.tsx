import { createFileRoute, Outlet, Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, History, User, CreditCard } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardLayout,
});

function DashboardLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = [
    { to: "/dashboard", icon: LayoutDashboard, label: "Overview" },
    { to: "/dashboard/history", icon: History, label: "History" },
    { to: "/dashboard/profile", icon: User, label: "Profile" },
    { to: "/dashboard/subscription", icon: CreditCard, label: "Subscription" },
  ] as const;
  return (
    <div className="container mx-auto px-4 py-10">
      <div className="grid gap-8 md:grid-cols-[220px_1fr]">
        <nav className="space-y-1">
          {items.map((i) => {
            const active = pathname === i.to;
            return (
              <Link key={i.to} to={i.to} className={`flex items-center gap-2 rounded-xl px-3 py-2 text-sm transition ${active ? "bg-gradient-brand text-brand-foreground shadow-glow" : "hover:bg-accent"}`}>
                <i.icon className="h-4 w-4" /> {i.label}
              </Link>
            );
          })}
        </nav>
        <div><Outlet /></div>
      </div>
    </div>
  );
}
