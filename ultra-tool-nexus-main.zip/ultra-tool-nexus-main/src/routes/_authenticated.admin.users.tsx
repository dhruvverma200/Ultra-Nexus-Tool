import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, doc, setDoc, deleteDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

interface UserRow { uid: string; email?: string; displayName?: string; role?: string }

export const Route = createFileRoute("/_authenticated/admin/users")({
  head: () => ({ meta: [{ title: "Users — Admin" }, { name: "robots", content: "noindex" }] }),
  component: UsersPage,
});

function UsersPage() {
  const [rows, setRows] = useState<UserRow[] | null>(null);

  async function load() {
    const [u, r] = await Promise.all([getDocs(collection(db, "users")), getDocs(collection(db, "user_roles"))]);
    const roles = new Map(r.docs.map((d) => [d.id, (d.data() as any).role as string]));
    setRows(u.docs.map((d) => ({ uid: d.id, ...(d.data() as any), role: roles.get(d.id) ?? "user" })));
  }
  useEffect(() => { load().catch(() => setRows([])); }, []);

  async function toggleAdmin(row: UserRow) {
    try {
      if (row.role === "admin") {
        await deleteDoc(doc(db, "user_roles", row.uid));
      } else {
        await setDoc(doc(db, "user_roles", row.uid), { uid: row.uid, role: "admin", createdAt: Date.now() });
      }
      toast.success("Role updated");
      load();
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Users</h1>
      <div className="mt-6">
        {rows === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
          : <div className="space-y-2">
              {rows.map((r) => (
                <Card key={r.uid} className="p-4 flex justify-between items-center">
                  <div>
                    <div className="font-medium text-sm">{r.displayName || r.email || r.uid}</div>
                    <div className="text-xs text-muted-foreground">{r.email}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs rounded-full bg-muted px-2 py-0.5">{r.role}</span>
                    <Button size="sm" variant="outline" onClick={() => toggleAdmin(r)}>
                      {r.role === "admin" ? "Revoke admin" : "Make admin"}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>}
      </div>
    </div>
  );
}
