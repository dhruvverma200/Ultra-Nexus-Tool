import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Card } from '@/components/ui/card';
import { Sparkles } from 'lucide-react';

export const Route = createFileRoute('/about')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto space-y-12">
          {/* Hero */}
          <div className="text-center">
            <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-brand text-brand-foreground shadow-glow">
              <Sparkles className="h-6 w-6" />
            </div>
            <h1 className="mt-6 font-display text-4xl font-bold">About OmniKit</h1>
            <p className="mt-3 text-lg text-muted-foreground">Your all-in-one workspace for premium tools.</p>
          </div>

          {/* Mission */}
          <Card className="p-8">
            <h2 className="font-display text-2xl font-bold">Our mission</h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              We believe everyone deserves access to premium tools without the complexity. OmniKit brings together 100+ carefully crafted tools
              in one beautifully designed workspace.
            </p>
          </Card>

          {/* Values */}
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: 'Privacy First',
                description: 'Your files process in your browser. We never store or track your data.',
              },
              {
                title: 'No Watermarks',
                description: 'Clean exports on the free tier. No hidden limitations or surprises.',
              },
              {
                title: 'Always Free',
                description: 'Start free with generous quotas. Upgrade only when you want more.',
              },
            ].map((value) => (
              <Card key={value.title} className="p-6">
                <h3 className="font-display font-semibold">{value.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{value.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
