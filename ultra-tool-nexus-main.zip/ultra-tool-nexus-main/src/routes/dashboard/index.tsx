import { createFileRoute } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { PageShell } from '@/components/PageShell';
import { DashboardSkeleton } from '@/components/skeletons';
import { useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { getSubscription, isUserPro } from '@/lib/subscription';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Link } from '@tanstack/react-router';
import { Zap, Calendar, CreditCard } from 'lucide-react';
import { useState } from 'react';
import { formatDate, formatCurrency } from '@/lib/utils';

export const Route = createFileRoute('/dashboard/')(() => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [isPro, setIsPro] = useState(false);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: '/auth', search: { redirect: '/dashboard' } });
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;

    const checkPro = async () => {
      try {
        const pro = await isUserPro(user.uid);
        setIsPro(pro);
      } catch (err) {
        console.error('Failed to check pro status:', err);
      } finally {
        setLoadingData(false);
      }
    };

    checkPro();
  }, [user]);

  if (loading || loadingData) {
    return (
      <PageShell>
        <div className="container mx-auto px-4 py-10">
          <DashboardSkeleton />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold">Welcome back!</h1>
          <p className="mt-2 text-muted-foreground">{user?.email}</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {/* Plan Card */}
          <Card className="p-6 md:col-span-2">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display text-lg font-semibold flex items-center gap-2">
                  <Zap className="h-5 w-5 text-brand" />
                  Your plan
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {isPro ? '🎉 You are on Pro plan' : '📦 You are on Free plan'}
                </p>
              </div>
              <Button asChild variant={isPro ? 'outline' : 'default'} className={isPro ? '' : 'bg-gradient-brand text-brand-foreground'}>
                <Link to="/dashboard/subscription">{isPro ? 'Manage' : 'Upgrade'}</Link>
              </Button>
            </div>
          </Card>

          {/* Quick Stats */}
          <Card className="p-6">
            <h3 className="font-display text-lg font-semibold flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Tools used
            </h3>
            <p className="mt-3 font-display text-3xl font-bold text-gradient-brand">23</p>
            <p className="text-xs text-muted-foreground mt-1">this month</p>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="mt-8">
          <h2 className="font-display text-xl font-bold mb-4">Quick links</h2>
          <div className="grid gap-4 md:grid-cols-3">
            <Button asChild variant="outline" className="h-auto p-4 justify-start">
              <Link to="/tools">
                <div className="text-left">
                  <div className="font-medium">Explore tools</div>
                  <div className="text-xs text-muted-foreground">Browse all 100+ tools</div>
                </div>
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto p-4 justify-start">
              <Link to="/dashboard/profile">
                <div className="text-left">
                  <div className="font-medium">Profile</div>
                  <div className="text-xs text-muted-foreground">Update your information</div>
                </div>
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-auto p-4 justify-start">
              <Link to="/pricing">
                <div className="text-left">
                  <div className="font-medium">Pricing</div>
                  <div className="text-xs text-muted-foreground">See all plans</div>
                </div>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
