import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useAuth } from '@/lib/auth-context';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useEffect, useState } from 'react';
import { getSubscription, type Subscription } from '@/lib/subscription';
import { SUBSCRIPTION_PLANS } from '@/lib/razorpay';
import { formatCurrency } from '@/lib/utils';
import { Check, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export const Route = createFileRoute('/dashboard/subscription')(() => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loadingData, setLoadingData] = useState(true);
  const [processingPlan, setProcessingPlan] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: '/auth', search: { redirect: '/dashboard/subscription' } });
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;

    const loadSubscription = async () => {
      try {
        const sub = await getSubscription(user.uid);
        setSubscription(sub);
      } catch (err) {
        console.error('Failed to load subscription:', err);
        toast.error('Failed to load subscription');
      } finally {
        setLoadingData(false);
      }
    };

    loadSubscription();
  }, [user]);

  const handleSelectPlan = async (planId: string) => {
    setProcessingPlan(planId);
    try {
      // Initialize Razorpay checkout
      const plan = SUBSCRIPTION_PLANS[planId as keyof typeof SUBSCRIPTION_PLANS];
      if (!plan) {
        toast.error('Invalid plan');
        return;
      }

      // Call backend to create order
      const response = await fetch('/api/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user!.uid,
          planId: planId,
          amount: plan.amount,
          email: user!.email,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create order');
      }

      const { orderId, key } = await response.json();

      // Open Razorpay checkout
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => {
        const options = {
          key,
          amount: plan.amount * 100, // Amount in paise
          currency: 'INR',
          name: 'OmniKit',
          description: `${plan.name} - ${plan.period}`,
          order_id: orderId,
          handler: async (response: any) => {
            try {
              const verifyResponse = await fetch('/api/razorpay/verify-payment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  razorpay_order_id: response.razorpay_order_id,
                  razorpay_payment_id: response.razorpay_payment_id,
                  razorpay_signature: response.razorpay_signature,
                  userId: user!.uid,
                  planId: planId,
                }),
              });

              if (!verifyResponse.ok) {
                throw new Error('Payment verification failed');
              }

              const result = await verifyResponse.json();
              if (result.success) {
                toast.success(`Welcome to ${plan.name}!`);
                setSubscription(result.subscription);
                navigate({ to: '/dashboard' });
              } else {
                toast.error('Payment verification failed');
              }
            } catch (err: any) {
              toast.error(err.message || 'Payment verification failed');
            }
          },
          prefill: {
            email: user!.email,
          },
          theme: {
            color: '#7c3aed',
          },
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.open();
      };
      document.body.appendChild(script);
    } catch (err: any) {
      toast.error(err.message || 'Failed to initiate payment');
    } finally {
      setProcessingPlan(null);
    }
  };

  if (loading || loadingData) {
    return (
      <PageShell>
        <div className="container mx-auto px-4 py-10">
          <div className="h-96 bg-card rounded-2xl border border-border/60 animate-pulse" />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="container mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Subscription</h1>
          {subscription && (
            <p className="mt-2 text-muted-foreground">
              Current plan: <span className="font-semibold text-foreground">{SUBSCRIPTION_PLANS[subscription.planId].name}</span>
            </p>
          )}
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {Object.entries(SUBSCRIPTION_PLANS).map(([key, plan]) => (
            <Card key={key} className={`p-6 flex flex-col ${subscription?.planId === key ? 'border-brand shadow-glow' : ''}`}>
              <h3 className="font-display text-lg font-semibold">{plan.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-3xl font-bold text-gradient-brand">{formatCurrency(plan.amount)}</span>
              </div>
              <div className="text-xs text-muted-foreground">{plan.period}</div>
              <p className="mt-4 text-sm text-muted-foreground">{plan.description}</p>
              <Button
                onClick={() => handleSelectPlan(key)}
                disabled={processingPlan === key || subscription?.planId === key}
                className={`mt-6 ${subscription?.planId === key ? 'opacity-50' : ''}`}
              >
                {processingPlan === key && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {subscription?.planId === key ? 'Current Plan' : 'Select'}
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
