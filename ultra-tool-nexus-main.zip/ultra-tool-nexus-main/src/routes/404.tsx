import { createFileRoute, Link } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertCircle, Home } from 'lucide-react';

export const Route = createFileRoute('/404')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-32">
        <div className="text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-destructive/15 text-destructive mb-4">
            <AlertCircle className="h-8 w-8" />
          </div>
          <h1 className="font-display text-5xl font-bold">404</h1>
          <p className="mt-3 text-muted-foreground">Page not found</p>
          <p className="mt-2 text-sm text-muted-foreground">The page you're looking for doesn't exist or has been moved.</p>
          <Button asChild className="mt-6 bg-gradient-brand text-brand-foreground">
            <Link to="/">
              <Home className="mr-2 h-4 w-4" />
              Go home
            </Link>
          </Button>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
