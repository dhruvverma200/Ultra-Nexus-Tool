import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/admin/ads")({
  head: () => ({ meta: [{ title: "Ads — Admin" }, { name: "robots", content: "noindex" }] }),
  component: () => (
    <div>
      <h1 className="font-display text-3xl font-bold">Ad slots</h1>
      <Card className="mt-6 p-10 text-center text-muted-foreground">Connect a Google AdSense client ID in admin settings to begin serving ads.</Card>
    </div>
  ),
});
