import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { ToolCard } from "@/components/ToolCard";
import { Button } from "@/components/ui/button";
import { TOOLS } from "@/lib/tools";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Sparkles, ShieldCheck, Zap, Heart, Star, ArrowRight, Check } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OmniKit — 100+ premium tools. One workspace." },
      { name: "description", content: "Edit PDFs, compress images, convert files, generate codes and more — all in one private, fast, premium workspace." },
      { property: "og:title", content: "OmniKit — 100+ premium tools. One workspace." },
      { property: "og:description", content: "Edit PDFs, compress images, convert files, generate codes and more." },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Landing,
});

function Landing() {
  const featured = TOOLS.filter((t) => t.implemented).slice(0, 8);

  return (
    <PageShell>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-aurora opacity-90" aria-hidden />
        <div className="absolute inset-0 bg-grid opacity-50" aria-hidden />
        <div className="container relative mx-auto px-4 py-24 md:py-32 text-center">
          <span className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs font-medium">
            <Sparkles className="h-3.5 w-3.5 text-brand" /> Now with 100+ tools
          </span>
          <h1 className="mt-6 font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight">
            100+ premium tools.
            <br />
            <span className="text-gradient-brand">One workspace.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            Edit PDFs, compress images, convert files, generate codes and run calculations — privately, in your browser. No watermarks. No installs.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="bg-gradient-brand text-brand-foreground shadow-glow hover:opacity-95">
              <Link to="/tools">Explore tools <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/pricing">View pricing</Link>
            </Button>
          </div>

          <div className="mx-auto mt-14 grid max-w-3xl grid-cols-3 gap-6">
            {[
              { value: "50k+", label: "Happy users" },
              { value: "100+", label: "Premium tools" },
              { value: "4.9★", label: "Avg rating" },
            ].map((s) => (
              <div key={s.label} className="glass rounded-2xl p-4">
                <div className="font-display text-2xl md:text-3xl font-bold text-gradient-brand">{s.value}</div>
                <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED TOOLS */}
      <section className="container mx-auto px-4 py-20">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Featured tools</h2>
            <p className="mt-2 text-muted-foreground">Battle-tested favorites used millions of times.</p>
          </div>
          <Button asChild variant="ghost">
            <Link to="/tools">All tools <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((t) => (
            <ToolCard key={t.slug} tool={t} />
          ))}
        </div>
      </section>

      {/* WHY */}
      <section className="border-y border-border/60 bg-card/30">
        <div className="container mx-auto grid gap-6 px-4 py-20 md:grid-cols-4">
          {[
            { icon: ShieldCheck, title: "Privacy first", desc: "Files process in your browser when possible. No tracking pixels." },
            { icon: Zap, title: "Lightning fast", desc: "Optimised for speed. Most tools run instantly, no upload roundtrip." },
            { icon: Heart, title: "No watermarks", desc: "Even on the free tier, your exports come out clean." },
            { icon: Star, title: "Free to start", desc: "Generous free quotas. Upgrade only when you want more." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-border/60 bg-background p-6">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-brand text-brand-foreground shadow-glow">
                <f.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container mx-auto px-4 py-20">
        <h2 className="text-center font-display text-3xl md:text-4xl font-bold">Loved by makers worldwide</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { name: "Aanya P.", role: "Designer", quote: "OmniKit replaced four tabs in my workflow. The PDF editor is genuinely premium." },
            { name: "Devon K.", role: "Engineer", quote: "JSON formatter, JWT decoder, hash generator — all in one tab. Bookmarked forever." },
            { name: "Maya R.", role: "Founder", quote: "We compress every product image through OmniKit. Free tier alone is incredible." },
          ].map((t) => (
            <figure key={t.name} className="rounded-2xl border border-border/60 bg-card p-6">
              <div className="flex gap-0.5 text-brand">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <blockquote className="mt-3 text-sm">"{t.quote}"</blockquote>
              <figcaption className="mt-4 text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{t.name}</span> · {t.role}
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="container mx-auto px-4 pb-20">
        <h2 className="text-center font-display text-3xl md:text-4xl font-bold">Frequently asked</h2>
        <div className="mx-auto mt-8 max-w-2xl">
          <Accordion type="single" collapsible>
            {[
              { q: "Is OmniKit really free?", a: "Yes. Most tools have a generous free quota. Pro unlocks higher limits and advanced tools." },
              { q: "Do you store my files?", a: "Most tools run in your browser and never upload your files. When upload is needed, files are deleted within an hour." },
              { q: "Can I cancel anytime?", a: "Absolutely. Subscriptions are managed from your dashboard, one click to cancel." },
              { q: "Is there a trial?", a: "Yes — a ₹1 trial unlocks all features for 7 days. First time only." },
            ].map((f) => (
              <AccordionItem key={f.q} value={f.q}>
                <AccordionTrigger className="text-left font-medium">{f.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 pb-24">
        <div className="relative overflow-hidden rounded-3xl border border-border bg-gradient-brand p-10 md:p-16 text-center text-brand-foreground shadow-glow">
          <div className="absolute inset-0 bg-grid opacity-20" aria-hidden />
          <div className="relative">
            <h2 className="font-display text-3xl md:text-5xl font-bold">Ready to work faster?</h2>
            <p className="mx-auto mt-3 max-w-xl opacity-90">Join 50,000+ users who replaced their toolkit with OmniKit.</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button asChild size="lg" variant="secondary">
                <Link to="/auth" search={{ mode: "signup" }}>Create free account <Check className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white/30 text-brand-foreground hover:bg-white/10">
                <Link to="/pricing">See pricing</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
