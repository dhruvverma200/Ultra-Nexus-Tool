import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { addDoc, collection, deleteDoc, doc, getDocs, orderBy, query, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Loader2, Trash2 } from "lucide-react";

interface Post { id: string; title: string; slug: string; excerpt: string; content: string; published: boolean; createdAt?: number }

export const Route = createFileRoute("/_authenticated/admin/blog")({
  head: () => ({ meta: [{ title: "Blog — Admin" }, { name: "robots", content: "noindex" }] }),
  component: BlogAdmin,
});

function BlogAdmin() {
  const [rows, setRows] = useState<Post[] | null>(null);
  const [draft, setDraft] = useState({ title: "", slug: "", excerpt: "", content: "", published: false });

  async function load() {
    const snap = await getDocs(query(collection(db, "blog_posts"), orderBy("createdAt", "desc")));
    setRows(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  }
  useEffect(() => { load().catch(() => setRows([])); }, []);

  async function create() {
    if (!draft.title || !draft.slug) { toast.error("Title and slug required"); return; }
    await addDoc(collection(db, "blog_posts"), { ...draft, createdAt: Date.now() });
    setDraft({ title: "", slug: "", excerpt: "", content: "", published: false });
    toast.success("Post created");
    load();
  }
  async function togglePublish(p: Post) { await updateDoc(doc(db, "blog_posts", p.id), { published: !p.published }); load(); }
  async function remove(p: Post) { await deleteDoc(doc(db, "blog_posts", p.id)); load(); }

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Blog</h1>
      <Card className="mt-6 p-5 space-y-3">
        <div className="grid gap-3 md:grid-cols-2">
          <div><Label>Title</Label><Input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></div>
          <div><Label>Slug</Label><Input value={draft.slug} onChange={(e) => setDraft({ ...draft, slug: e.target.value })} /></div>
        </div>
        <div><Label>Excerpt</Label><Input value={draft.excerpt} onChange={(e) => setDraft({ ...draft, excerpt: e.target.value })} /></div>
        <div><Label>Markdown content</Label><Textarea rows={6} value={draft.content} onChange={(e) => setDraft({ ...draft, content: e.target.value })} /></div>
        <div className="flex items-center gap-2"><Switch checked={draft.published} onCheckedChange={(v) => setDraft({ ...draft, published: v })} /><span className="text-sm">Published</span></div>
        <Button onClick={create} className="bg-gradient-brand text-brand-foreground">Create post</Button>
      </Card>

      <div className="mt-8">
        {rows === null ? <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
          : <div className="space-y-2">
              {rows.map((p) => (
                <Card key={p.id} className="p-4 flex justify-between items-center">
                  <div><div className="font-medium text-sm">{p.title}</div><div className="text-xs text-muted-foreground">/blog/{p.slug}</div></div>
                  <div className="flex items-center gap-3">
                    <Switch checked={p.published} onCheckedChange={() => togglePublish(p)} />
                    <Button variant="ghost" size="icon" onClick={() => remove(p)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </Card>
              ))}
            </div>}
      </div>
    </div>
  );
}
