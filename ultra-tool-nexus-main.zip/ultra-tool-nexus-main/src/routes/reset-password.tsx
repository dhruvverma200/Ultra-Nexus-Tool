import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { confirmPasswordReset, verifyPasswordResetCode } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

const searchSchema = z.object({
  oobCode: z.string().optional(),
  mode: z.string().optional(),
});

export const Route = createFileRoute("/reset-password")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({ meta: [{ title: "Set a new password — OmniKit" }, { name: "robots", content: "noindex" }] }),
  component: ResetPassword,
});

function ResetPassword() {
  const { oobCode } = Route.useSearch();
  const navigate = useNavigate();
  const [verifiedEmail, setVerifiedEmail] = useState<string | null>(null);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!oobCode) {
      setError("Missing reset code. Please use the link in your email.");
      return;
    }
    verifyPasswordResetCode(auth, oobCode)
      .then(setVerifiedEmail)
      .catch((err) => setError(err?.message ?? "Invalid or expired reset link"));
  }, [oobCode]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!oobCode) return;
    setBusy(true);
    try {
      await confirmPasswordReset(auth, oobCode, password);
      toast.success("Password updated — please sign in.");
      navigate({ to: "/auth" });
    } catch (err: any) {
      toast.error(err?.message ?? "Could not update password");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-aurora px-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex justify-center"><Logo /></div>
        <div className="rounded-3xl border border-border bg-card p-6 shadow-glow">
          <h1 className="font-display text-2xl font-bold">Set a new password</h1>
          {error ? (
            <p className="mt-4 text-sm text-destructive">{error}</p>
          ) : !verifiedEmail ? (
            <p className="mt-4 text-sm text-muted-foreground"><Loader2 className="inline h-4 w-4 animate-spin mr-2" /> Verifying link…</p>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-3">
              <p className="text-sm text-muted-foreground">Resetting password for <strong>{verifiedEmail}</strong></p>
              <div className="space-y-1.5">
                <Label htmlFor="pw">New password</Label>
                <Input id="pw" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <Button type="submit" className="w-full bg-gradient-brand text-brand-foreground" disabled={busy}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Update password"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
