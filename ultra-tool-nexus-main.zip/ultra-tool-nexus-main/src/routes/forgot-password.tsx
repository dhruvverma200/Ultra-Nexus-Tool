import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useState } from 'react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Logo } from '@/components/Logo';
import { toast } from 'sonner';
import { Loader2, ArrowLeft, Mail } from 'lucide-react';

export const Route = createFileRoute('/forgot-password')({
  head: () => ({
    meta: [
      { title: 'Forgot Password — OmniKit' },
      { name: 'description', content: 'Reset your OmniKit password.' },
      { name: 'robots', content: 'noindex' },
    ],
  }),
  component: ForgotPassword,
});

function ForgotPassword() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSendReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error('Please enter your email');
      return;
    }

    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setSent(true);
      toast.success('Password reset email sent');
    } catch (err: any) {
      if (err.code === 'auth/user-not-found') {
        toast.error('No account found with this email');
      } else {
        toast.error(err.message || 'Failed to send reset email');
      }
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-aurora px-4">
        <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 text-center shadow-glow">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-brand text-brand-foreground">
            <Mail className="h-7 w-7" />
          </div>
          <h1 className="mt-4 font-display text-2xl font-bold">Check your email</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We sent a password reset link to <strong>{email}</strong>. Click it to create a new password.
          </p>
          <Button className="mt-6 w-full bg-gradient-brand text-brand-foreground" onClick={() => navigate({ to: '/auth' })}>
            Back to sign in
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-aurora px-4 py-10">
      <div className="w-full max-w-md">
        <button
          onClick={() => (window.history.length > 1 ? window.history.back() : navigate({ to: '/' }))}
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <div className="mb-6 flex justify-center">
          <Logo />
        </div>
        <div className="rounded-3xl border border-border bg-card p-6 shadow-glow">
          <h1 className="font-display text-2xl font-bold">Forgot password?</h1>
          <p className="mt-2 text-sm text-muted-foreground">Enter your email to receive a password reset link.</p>

          <form onSubmit={handleSendReset} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <Button type="submit" className="w-full bg-gradient-brand text-brand-foreground" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              Send reset link
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
