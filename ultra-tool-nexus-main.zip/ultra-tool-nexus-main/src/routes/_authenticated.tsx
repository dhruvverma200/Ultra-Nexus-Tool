import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { ProtectedRoute } from "@/components/ProtectedRoute";

export const Route = createFileRoute("/_authenticated")({
  component: () => (
    <ProtectedRoute>
      <PageShell><Outlet /></PageShell>
    </ProtectedRoute>
  ),
});
