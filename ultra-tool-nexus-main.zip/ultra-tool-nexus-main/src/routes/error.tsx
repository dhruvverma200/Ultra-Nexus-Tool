import { createFileRoute } from '@tanstack/react-router';
import { PageShell } from '@/components/PageShell';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertTriangle, Home } from 'lucide-react';
import { Link } from '@tanstack/react-router';

export const Route = createFileRoute('/error')(() => {
  return (
    <PageShell>
      <div className="container mx-auto px-4 py-32">
        <div className="text-center">
          <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-destructive/15 text-destructive mb-4">
            <AlertTriangle className="h-8 w-8" />
          </div>
          <h1 className="font-display text-4xl font-bold">Something went wrong</h1>
          <p className="mt-3 text-muted-foreground">We encountered an unexpected error. Please try again or go home.</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button asChild className="bg-gradient-brand text-brand-foreground">
              <Link to="/">
                <Home className="mr-2 h-4 w-4" />
                Go home
              </Link>
            </Button>
            <Button variant="outline" onClick={() => window.location.reload()}>
              Refresh page
            </Button>
          </div>
        </div>
      </div>
    </PageShell>
  );
});

export default Route.component;
