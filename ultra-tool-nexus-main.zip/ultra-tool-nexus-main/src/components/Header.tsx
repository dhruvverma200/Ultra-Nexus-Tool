import { Link, useNavigate } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, LayoutDashboard, Shield, Settings } from "lucide-react";

export function Header() {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 backdrop-blur-md bg-background/70">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-8">
          <Logo />
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <Link to="/tools" className="text-muted-foreground hover:text-foreground transition" activeProps={{ className: "text-foreground font-medium" }}>
              Tools
            </Link>
            <Link to="/pricing" className="text-muted-foreground hover:text-foreground transition" activeProps={{ className: "text-foreground font-medium" }}>
              Pricing
            </Link>
            <Link to="/blog" className="text-muted-foreground hover:text-foreground transition" activeProps={{ className: "text-foreground font-medium" }}>
              Blog
            </Link>
            <Link to="/about" className="text-muted-foreground hover:text-foreground transition" activeProps={{ className: "text-foreground font-medium" }}>
              About
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="rounded-full focus:outline-none focus:ring-2 focus:ring-ring">
                  <Avatar className="h-9 w-9 border border-border">
                    <AvatarImage src={user.photoURL ?? undefined} alt={user.displayName ?? user.email ?? ""} />
                    <AvatarFallback className="bg-gradient-brand text-brand-foreground text-xs">
                      {(user.displayName ?? user.email ?? "U")[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="text-sm font-medium truncate">{user.displayName ?? "Account"}</div>
                  <div className="text-xs text-muted-foreground truncate">{user.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate({ to: "/dashboard" })}>
                  <LayoutDashboard className="mr-2 h-4 w-4" /> Dashboard
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate({ to: "/dashboard/profile" })}>
                  <Settings className="mr-2 h-4 w-4" /> Profile
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem onClick={() => navigate({ to: "/admin" })}>
                    <Shield className="mr-2 h-4 w-4" /> Admin
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={async () => {
                    await signOut();
                    navigate({ to: "/" });
                  }}
                >
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/auth" })}>
                Sign in
              </Button>
              <Button size="sm" className="bg-gradient-brand text-brand-foreground shadow-glow hover:opacity-95" onClick={() => navigate({ to: "/auth", search: { mode: "signup" } })}>
                Get started
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
