import React, { useEffect, useState } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error) {
    console.error('Error caught by boundary:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-background">
          <Card className="w-full max-w-md p-8">
            <div className="flex justify-center">
              <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/15 text-destructive">
                <AlertCircle className="h-6 w-6" />
              </div>
            </div>
            <h1 className="mt-4 font-display text-xl font-bold text-center">Something went wrong</h1>
            <p className="mt-2 text-sm text-muted-foreground text-center">
              {this.state.error?.message || 'An unexpected error occurred'}
            </p>
            <Button
              onClick={() => window.location.reload()}
              className="mt-6 w-full bg-gradient-brand text-brand-foreground"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh page
            </Button>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}
