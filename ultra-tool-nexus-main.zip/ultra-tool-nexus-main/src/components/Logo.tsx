import { Link } from "@tanstack/react-router";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`group inline-flex items-center gap-2 ${className}`}>
      <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-brand text-brand-foreground shadow-glow">
        <span className="font-display text-base font-bold">O</span>
      </span>
      <span className="font-display text-lg font-bold tracking-tight">
        Omni<span className="text-gradient-brand">Kit</span>
      </span>
    </Link>
  );
}
