import { Link } from "@tanstack/react-router";
import * as Icons from "lucide-react";
import type { Tool } from "@/lib/tools";
import { getToolHref } from "@/lib/tools";
import { ArrowUpRight } from "lucide-react";

export function ToolCard({ tool }: { tool: Tool }) {
  const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[tool.icon] ?? Icons.Wrench;
  return (
    <Link
      to={getToolHref(tool)}
      className="group relative flex flex-col gap-3 rounded-2xl border border-border/70 bg-card p-5 transition hover:border-brand/50 hover:shadow-glow"
    >
      <div className="flex items-center justify-between">
        <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-brand/10 text-brand">
          <Icon className="h-5 w-5" />
        </div>
        <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
      </div>
      <div>
        <h3 className="font-display text-base font-semibold leading-tight">{tool.name}</h3>
        <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{tool.description}</p>
      </div>
      {tool.implemented && (
        <span className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-medium text-success">
          Live
        </span>
      )}
    </Link>
  );
}
