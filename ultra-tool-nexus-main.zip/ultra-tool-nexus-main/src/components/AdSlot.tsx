export function AdSlot({ id, className = "" }: { id: string; className?: string }) {
  return (
    <div
      data-ad-slot={id}
      className={`flex min-h-24 items-center justify-center rounded-xl border border-dashed border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground ${className}`}
    >
      Ad slot · {id}
    </div>
  );
}
