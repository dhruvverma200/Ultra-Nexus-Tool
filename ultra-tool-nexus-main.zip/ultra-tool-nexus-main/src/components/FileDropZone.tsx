import { useCallback, useRef, useState, type ReactNode } from "react";
import { UploadCloud } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  accept?: string;
  multiple?: boolean;
  onFiles: (files: File[]) => void;
  className?: string;
  children?: ReactNode;
}

export function FileDropZone({ accept, multiple, onFiles, className, children }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFiles = useCallback(
    (list: FileList | null) => {
      if (!list || list.length === 0) return;
      const files = Array.from(list);
      onFiles(multiple ? files : [files[0]]);
    },
    [onFiles, multiple],
  );

  return (
    <button
      type="button"
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        handleFiles(e.dataTransfer.files);
      }}
      className={cn(
        "group flex w-full flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-10 text-center transition",
        dragging ? "border-brand bg-brand/5" : "border-border bg-card/40 hover:border-brand/60 hover:bg-card",
        className,
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      {children ?? (
        <>
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-brand text-brand-foreground shadow-glow">
            <UploadCloud className="h-6 w-6" />
          </span>
          <div>
            <p className="font-display text-base font-semibold">Drop files here</p>
            <p className="mt-1 text-sm text-muted-foreground">or click to choose from your device</p>
          </div>
        </>
      )}
    </button>
  );
}
