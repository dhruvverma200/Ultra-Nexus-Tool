import type { Mode } from "./types";
import { FileDropZone } from "@/components/FileDropZone";
import { Construction } from "lucide-react";

const labels: Record<string, { title: string; desc: string }> = {
  sign: { title: "Sign PDF", desc: "Draw or upload your signature and place it anywhere on the document." },
  stamp: { title: "Stamp PDF", desc: "Apply Approved, Draft, Confidential and custom stamps." },
  annotate: { title: "Annotate PDF", desc: "Highlight, underline, and add sticky notes." },
  fill: { title: "Fill PDF Form", desc: "Fill out interactive PDF form fields and export." },
  edit: { title: "Edit PDF", desc: "Add text, images and shapes to your PDF." },
};

export type { Mode };

export function PdfEditor({ mode }: { mode: keyof typeof labels }) {
  const meta = labels[mode];
  return (
    <div>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">Editor mode · <span className="rounded-full bg-brand/10 px-2 py-0.5 text-brand font-medium">{mode}</span></div>
      <h1 className="mt-2 font-display text-3xl md:text-4xl font-bold">{meta.title}</h1>
      <p className="mt-2 text-muted-foreground max-w-2xl">{meta.desc}</p>

      <div className="mt-8">
        <FileDropZone accept="application/pdf" onFiles={() => {}} />
      </div>

      <div className="mt-8 rounded-2xl border border-dashed border-border bg-muted/30 p-8 text-center">
        <Construction className="mx-auto h-8 w-8 text-muted-foreground" />
        <p className="mt-3 text-sm text-muted-foreground">
          The full <strong>{meta.title}</strong> workspace is rolling out. Drop your PDF above to be queued in — we'll email you when it's live.
        </p>
      </div>
    </div>
  );
}
