export type Mode = "sign" | "stamp" | "annotate" | "fill" | "edit";
