import { lazy, Suspense } from "react";
import type { Tool } from "@/lib/tools";
import { Construction, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "@tanstack/react-router";

// Lazy-loaded tool implementations
const impls: Record<string, React.LazyExoticComponent<React.ComponentType>> = {
  "word-counter": lazy(() => import("./impl/WordCounter")),
  "case-converter": lazy(() => import("./impl/CaseConverter")),
  "lorem-ipsum": lazy(() => import("./impl/LoremIpsum")),
  "json-formatter": lazy(() => import("./impl/JsonFormatter")),
  "base64": lazy(() => import("./impl/Base64")),
  "url-encode": lazy(() => import("./impl/UrlEncode")),
  "hash-generator": lazy(() => import("./impl/HashGenerator")),
  "password-generator": lazy(() => import("./impl/PasswordGenerator")),
  "jwt-decoder": lazy(() => import("./impl/JwtDecoder")),
  "uuid-generator": lazy(() => import("./impl/UuidGenerator")),
  "unix-timestamp": lazy(() => import("./impl/UnixTimestamp")),
  "emi-calculator": lazy(() => import("./impl/EmiCalculator")),
  "gst-calculator": lazy(() => import("./impl/GstCalculator")),
  "age-calculator": lazy(() => import("./impl/AgeCalculator")),
  "bmi-calculator": lazy(() => import("./impl/BmiCalculator")),
  "percentage-calculator": lazy(() => import("./impl/PercentageCalculator")),
  "pomodoro": lazy(() => import("./impl/Pomodoro")),
  "stopwatch": lazy(() => import("./impl/Stopwatch")),
  "world-clock": lazy(() => import("./impl/WorldClock")),
  "image-compress": lazy(() => import("./impl/ImageCompress")),
  "image-resize": lazy(() => import("./impl/ImageResize")),
  "image-convert": lazy(() => import("./impl/ImageConvert")),
  "jpg-to-pdf": lazy(() => import("./impl/JpgToPdf")),
};

export function ToolRunner({ tool }: { tool: Tool }) {
  const Impl = impls[tool.slug];
  if (Impl) {
    return (
      <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>}>
        <Impl />
      </Suspense>
    );
  }
  return (
    <div className="rounded-2xl border border-dashed border-border bg-muted/30 p-10 text-center">
      <Construction className="mx-auto h-10 w-10 text-muted-foreground" />
      <h3 className="mt-4 font-display text-xl font-semibold">Coming soon</h3>
      <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
        We're rolling out <strong>{tool.name}</strong> to all users shortly. Subscribe to OmniKit Pro to get early access.
      </p>
      <div className="mt-5 flex justify-center gap-2">
        <Button asChild className="bg-gradient-brand text-brand-foreground">
          <Link to="/pricing">Get early access</Link>
        </Button>
        <Button asChild variant="outline">
          <Link to="/tools">Browse other tools</Link>
        </Button>
      </div>
    </div>
  );
}
