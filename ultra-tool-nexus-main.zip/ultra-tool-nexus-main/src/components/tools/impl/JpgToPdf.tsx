import { useState } from "react";
import { FileDropZone } from "@/components/FileDropZone";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

async function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

export default function JpgToPdf() {
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState<string | null>(null);

  async function run() {
    if (files.length === 0) return;
    setBusy(true);
    try {
      // Lazy-load jspdf only when needed; warn if not installed yet
      const mod = await import("jspdf").catch(() => null);
      if (!mod) { toast.error("PDF engine unavailable."); return; }
      const { jsPDF } = mod;
      const doc = new jsPDF({ unit: "px" });
      for (let i = 0; i < files.length; i++) {
        const img = await loadImage(files[i]);
        if (i > 0) doc.addPage([img.width, img.height], img.width > img.height ? "l" : "p");
        else doc.internal.pageSize = { width: img.width, height: img.height } as any;
        doc.addImage(img, "JPEG", 0, 0, img.width, img.height);
      }
      const blob = doc.output("blob");
      setUrl(URL.createObjectURL(blob));
    } catch (e: any) {
      toast.error(e.message);
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      <FileDropZone accept="image/jpeg,image/png" multiple onFiles={(f) => { setFiles(f); setUrl(null); }} />
      {files.length > 0 && (
        <Card className="p-5 space-y-3">
          <div className="text-sm">{files.length} image{files.length > 1 ? "s" : ""} selected</div>
          <Button onClick={run} disabled={busy} className="bg-gradient-brand text-brand-foreground">Create PDF</Button>
          {url && <Button asChild variant="outline"><a href={url} download="omnikit.pdf">Download PDF</a></Button>}
        </Card>
      )}
    </div>
  );
}
