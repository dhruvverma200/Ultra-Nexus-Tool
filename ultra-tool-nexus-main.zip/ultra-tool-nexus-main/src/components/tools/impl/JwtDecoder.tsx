import { useMemo, useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";

function decodePart(s: string) {
  try {
    const pad = "=".repeat((4 - (s.length % 4)) % 4);
    const b = (s + pad).replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(decodeURIComponent(escape(atob(b))));
  } catch { return null; }
}

export default function JwtDecoder() {
  const [t, setT] = useState("");
  const parts = useMemo(() => {
    const [h, p, s] = t.split(".");
    return { header: h ? decodePart(h) : null, payload: p ? decodePart(p) : null, signature: s ?? "" };
  }, [t]);
  return (
    <div className="space-y-4">
      <Textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Paste JWT…" className="min-h-[140px] font-mono text-sm" />
      <div className="grid gap-3 lg:grid-cols-2">
        <Card className="p-4">
          <div className="text-xs font-medium text-brand">Header</div>
          <pre className="mt-2 text-xs overflow-auto">{parts.header ? JSON.stringify(parts.header, null, 2) : "—"}</pre>
        </Card>
        <Card className="p-4">
          <div className="text-xs font-medium text-brand">Payload</div>
          <pre className="mt-2 text-xs overflow-auto">{parts.payload ? JSON.stringify(parts.payload, null, 2) : "—"}</pre>
        </Card>
      </div>
      <Card className="p-4">
        <div className="text-xs font-medium text-brand">Signature</div>
        <div className="mt-2 break-all font-mono text-xs">{parts.signature || "—"}</div>
      </Card>
    </div>
  );
}
