import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Stopwatch() {
  const [ms, setMs] = useState(0);
  const [running, setRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const ref = useRef<number | null>(null);
  const start = useRef(0);
  const base = useRef(0);
  useEffect(() => {
    if (!running) return;
    start.current = performance.now();
    ref.current = window.setInterval(() => setMs(base.current + (performance.now() - start.current)), 33);
    return () => { if (ref.current) clearInterval(ref.current); base.current = ms; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);
  const fmt = (m: number) => {
    const cs = Math.floor((m % 1000) / 10);
    const s = Math.floor(m / 1000) % 60;
    const min = Math.floor(m / 60000);
    return `${String(min).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
  };
  return (
    <Card className="mx-auto max-w-md p-10 text-center">
      <div className="font-display text-6xl font-bold tabular-nums text-gradient-brand">{fmt(ms)}</div>
      <div className="mt-6 flex justify-center gap-2">
        <Button onClick={() => setRunning((r) => !r)} className="bg-gradient-brand text-brand-foreground">{running ? "Pause" : "Start"}</Button>
        <Button variant="outline" onClick={() => setLaps((l) => [ms, ...l])}>Lap</Button>
        <Button variant="ghost" onClick={() => { setRunning(false); setMs(0); base.current = 0; setLaps([]); }}>Reset</Button>
      </div>
      {laps.length > 0 && (
        <div className="mt-6 space-y-1 text-left text-sm font-mono">
          {laps.map((l, i) => <div key={i} className="flex justify-between rounded bg-muted/40 px-3 py-1"><span>Lap {laps.length - i}</span><span>{fmt(l)}</span></div>)}
        </div>
      )}
    </Card>
  );
}
