import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function JsonFormatter() {
  const [input, setInput] = useState('{"hello":"world","n":[1,2,3]}');
  const [output, setOutput] = useState("");
  const [err, setErr] = useState<string | null>(null);

  function format(indent: number) {
    try {
      setOutput(JSON.stringify(JSON.parse(input), null, indent));
      setErr(null);
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="space-y-2">
        <Textarea value={input} onChange={(e) => setInput(e.target.value)} className="min-h-[420px] font-mono text-sm" />
        <div className="flex gap-2">
          <Button onClick={() => format(2)} className="bg-gradient-brand text-brand-foreground">Format</Button>
          <Button variant="outline" onClick={() => format(0)}>Minify</Button>
          <Button variant="ghost" onClick={() => setInput(output)}>← Use output</Button>
        </div>
        {err && <p className="text-sm text-destructive">{err}</p>}
      </div>
      <div className="space-y-2">
        <Textarea readOnly value={output} className="min-h-[420px] font-mono text-sm bg-muted/30" />
        <Button variant="outline" onClick={async () => { await navigator.clipboard.writeText(output); toast.success("Copied"); }}>Copy output</Button>
      </div>
    </div>
  );
}
