import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";

function gen(len: number, upper: boolean, lower: boolean, num: boolean, sym: boolean) {
  let pool = "";
  if (upper) pool += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  if (lower) pool += "abcdefghijklmnopqrstuvwxyz";
  if (num) pool += "0123456789";
  if (sym) pool += "!@#$%^&*()-_=+[]{};:,.<>?";
  if (!pool) return "";
  const arr = new Uint32Array(len);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((n) => pool[n % pool.length]).join("");
}

export default function PasswordGenerator() {
  const [len, setLen] = useState(20);
  const [upper, setUpper] = useState(true);
  const [lower, setLower] = useState(true);
  const [num, setNum] = useState(true);
  const [sym, setSym] = useState(true);
  const [pw, setPw] = useState(() => gen(20, true, true, true, true));
  const strength = useMemo(() => Math.min(100, Math.round((pw.length / 32) * 100)), [pw]);

  return (
    <div className="max-w-2xl space-y-6">
      <div className="rounded-2xl border border-border bg-card p-6">
        <Input readOnly value={pw} className="font-mono text-lg h-14" />
        <div className="mt-3 flex gap-2">
          <Button className="bg-gradient-brand text-brand-foreground flex-1" onClick={() => setPw(gen(len, upper, lower, num, sym))}>Regenerate</Button>
          <Button variant="outline" onClick={async () => { await navigator.clipboard.writeText(pw); toast.success("Copied"); }}>Copy</Button>
        </div>
        <div className="mt-4 h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-gradient-brand" style={{ width: `${strength}%` }} />
        </div>
      </div>
      <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
        <div>
          <Label>Length: {len}</Label>
          <Slider value={[len]} onValueChange={(v) => setLen(v[0])} min={8} max={64} step={1} />
        </div>
        {[
          { l: "Uppercase (A-Z)", v: upper, s: setUpper },
          { l: "Lowercase (a-z)", v: lower, s: setLower },
          { l: "Numbers (0-9)", v: num, s: setNum },
          { l: "Symbols (!@#…)", v: sym, s: setSym },
        ].map((o) => (
          <div key={o.l} className="flex items-center justify-between">
            <Label>{o.l}</Label>
            <Switch checked={o.v} onCheckedChange={o.s} />
          </div>
        ))}
      </div>
    </div>
  );
}
