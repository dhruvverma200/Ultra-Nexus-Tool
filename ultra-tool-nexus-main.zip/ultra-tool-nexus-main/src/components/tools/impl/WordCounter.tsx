import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";

export default function WordCounter() {
  const [t, setT] = useState("");
  const words = t.trim() ? t.trim().split(/\s+/).length : 0;
  const chars = t.length;
  const charsNoSpace = t.replace(/\s/g, "").length;
  const sentences = t.split(/[.!?]+/).filter((s) => s.trim()).length;
  const paragraphs = t.split(/\n+/).filter((p) => p.trim()).length;
  const reading = Math.max(1, Math.round(words / 200));

  return (
    <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
      <Textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Paste or type your text…" className="min-h-[400px] text-base" />
      <div className="grid grid-cols-2 gap-3">
        {[
          { l: "Words", v: words },
          { l: "Characters", v: chars },
          { l: "No spaces", v: charsNoSpace },
          { l: "Sentences", v: sentences },
          { l: "Paragraphs", v: paragraphs },
          { l: "Reading min", v: reading },
        ].map((s) => (
          <Card key={s.l} className="p-4">
            <div className="text-xs text-muted-foreground">{s.l}</div>
            <div className="mt-1 font-display text-2xl font-bold text-gradient-brand">{s.v}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
