import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function GstCalculator() {
  const [amt, setAmt] = useState(1000);
  const [rate, setRate] = useState(18);
  const add = { gst: (amt * rate) / 100, total: amt + (amt * rate) / 100 };
  const remove = { base: amt / (1 + rate / 100), gst: amt - amt / (1 + rate / 100) };
  const fmt = (x: number) => "₹" + x.toFixed(2);
  return (
    <div className="max-w-2xl">
      <Card className="p-6 space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label>Amount (₹)</Label>
            <Input type="number" value={amt} onChange={(e) => setAmt(Number(e.target.value))} />
          </div>
          <div>
            <Label>GST rate (%)</Label>
            <Input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} />
          </div>
        </div>
        <Tabs defaultValue="add">
          <TabsList><TabsTrigger value="add">Add GST</TabsTrigger><TabsTrigger value="remove">Remove GST</TabsTrigger></TabsList>
          <TabsContent value="add" className="grid grid-cols-3 gap-3 pt-4">
            <div><div className="text-xs text-muted-foreground">Base</div><div className="font-display text-lg font-bold">{fmt(amt)}</div></div>
            <div><div className="text-xs text-muted-foreground">GST</div><div className="font-display text-lg font-bold">{fmt(add.gst)}</div></div>
            <div><div className="text-xs text-muted-foreground">Total</div><div className="font-display text-lg font-bold text-gradient-brand">{fmt(add.total)}</div></div>
          </TabsContent>
          <TabsContent value="remove" className="grid grid-cols-3 gap-3 pt-4">
            <div><div className="text-xs text-muted-foreground">Total</div><div className="font-display text-lg font-bold">{fmt(amt)}</div></div>
            <div><div className="text-xs text-muted-foreground">GST</div><div className="font-display text-lg font-bold">{fmt(remove.gst)}</div></div>
            <div><div className="text-xs text-muted-foreground">Base</div><div className="font-display text-lg font-bold text-gradient-brand">{fmt(remove.base)}</div></div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
