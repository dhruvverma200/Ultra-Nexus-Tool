import { useState } from "react";
import { FileDropZone } from "@/components/FileDropZone";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

async function compress(file: File, quality: number): Promise<{ blob: Blob; url: string }> {
  const bmp = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  canvas.width = bmp.width;
  canvas.height = bmp.height;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(bmp, 0, 0);
  const blob: Blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b!), "image/jpeg", quality));
  return { blob, url: URL.createObjectURL(blob) };
}

export default function ImageCompress() {
  const [file, setFile] = useState<File | null>(null);
  const [quality, setQuality] = useState(0.75);
  const [out, setOut] = useState<{ blob: Blob; url: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function run() {
    if (!file) return;
    setBusy(true);
    try {
      const r = await compress(file, quality);
      setOut(r);
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <FileDropZone accept="image/*" onFiles={(f) => { setFile(f[0]); setOut(null); }} />
      {file && (
        <Card className="p-5 space-y-4">
          <div className="flex items-center justify-between text-sm">
            <span>{file.name}</span>
            <span className="text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</span>
          </div>
          <div>
            <Label>Quality: {Math.round(quality * 100)}%</Label>
            <Slider value={[quality * 100]} onValueChange={(v) => setQuality(v[0] / 100)} min={10} max={100} />
          </div>
          <Button onClick={run} disabled={busy} className="bg-gradient-brand text-brand-foreground">Compress</Button>
          {out && (
            <div className="rounded-xl border border-success/30 bg-success/10 p-4 flex items-center justify-between gap-3">
              <span className="text-sm">Compressed to {(out.blob.size / 1024).toFixed(1)} KB ({Math.round(100 - (out.blob.size / file.size) * 100)}% smaller)</span>
              <Button asChild variant="outline" size="sm"><a href={out.url} download={`compressed-${file.name.replace(/\.[^.]+$/, ".jpg")}`}>Download</a></Button>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
