import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";

const ZONES = [
  { city: "San Francisco", tz: "America/Los_Angeles" },
  { city: "New York", tz: "America/New_York" },
  { city: "London", tz: "Europe/London" },
  { city: "Berlin", tz: "Europe/Berlin" },
  { city: "Dubai", tz: "Asia/Dubai" },
  { city: "Mumbai", tz: "Asia/Kolkata" },
  { city: "Singapore", tz: "Asia/Singapore" },
  { city: "Tokyo", tz: "Asia/Tokyo" },
  { city: "Sydney", tz: "Australia/Sydney" },
];

export default function WorldClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const i = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {ZONES.map((z) => (
        <Card key={z.tz} className="p-5">
          <div className="text-xs text-muted-foreground">{z.tz}</div>
          <div className="font-display text-xl font-semibold">{z.city}</div>
          <div className="mt-2 font-display text-3xl font-bold tabular-nums text-gradient-brand">
            {now.toLocaleTimeString("en-GB", { timeZone: z.tz, hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            {now.toLocaleDateString("en-GB", { timeZone: z.tz, weekday: "short", day: "numeric", month: "short" })}
          </div>
        </Card>
      ))}
    </div>
  );
}
