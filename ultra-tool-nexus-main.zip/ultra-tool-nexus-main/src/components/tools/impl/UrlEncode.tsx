import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function UrlEncode() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Textarea value={input} onChange={(e) => setInput(e.target.value)} className="min-h-[300px]" placeholder="Input URL or text" />
      <div className="space-y-3">
        <Textarea readOnly value={output} className="min-h-[240px] bg-muted/30" />
        <div className="flex gap-2">
          <Button onClick={() => setOutput(encodeURIComponent(input))} className="bg-gradient-brand text-brand-foreground">Encode</Button>
          <Button variant="outline" onClick={() => { try { setOutput(decodeURIComponent(input)); } catch { toast.error("Invalid encoding"); } }}>Decode</Button>
          <Button variant="ghost" onClick={async () => { await navigator.clipboard.writeText(output); toast.success("Copied"); }}>Copy</Button>
        </div>
      </div>
    </div>
  );
}
