import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function EmiCalculator() {
  const [p, setP] = useState(1000000);
  const [r, setR] = useState(8.5);
  const [n, setN] = useState(20);
  const months = n * 12;
  const monthly = r / 12 / 100;
  const emi = (p * monthly * Math.pow(1 + monthly, months)) / (Math.pow(1 + monthly, months) - 1);
  const total = emi * months;
  const interest = total - p;
  const fmt = (x: number) => isFinite(x) ? "₹" + Math.round(x).toLocaleString("en-IN") : "—";
  return (
    <div className="grid gap-6 lg:grid-cols-[2fr_1fr]">
      <Card className="p-6 space-y-4">
        <div>
          <Label>Loan amount (₹)</Label>
          <Input type="number" value={p} onChange={(e) => setP(Number(e.target.value))} />
        </div>
        <div>
          <Label>Interest rate (% p.a.)</Label>
          <Input type="number" step="0.1" value={r} onChange={(e) => setR(Number(e.target.value))} />
        </div>
        <div>
          <Label>Tenure (years)</Label>
          <Input type="number" value={n} onChange={(e) => setN(Number(e.target.value))} />
        </div>
      </Card>
      <div className="space-y-3">
        <Card className="p-5"><div className="text-xs text-muted-foreground">Monthly EMI</div><div className="mt-1 font-display text-2xl font-bold text-gradient-brand">{fmt(emi)}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">Total interest</div><div className="mt-1 font-display text-xl font-bold">{fmt(interest)}</div></Card>
        <Card className="p-5"><div className="text-xs text-muted-foreground">Total payment</div><div className="mt-1 font-display text-xl font-bold">{fmt(total)}</div></Card>
      </div>
    </div>
  );
}
