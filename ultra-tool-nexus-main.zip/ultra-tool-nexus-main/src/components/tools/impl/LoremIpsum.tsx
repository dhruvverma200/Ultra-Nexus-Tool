import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const SOURCE = "Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum".split(" ");

function gen(paragraphs: number, wordsPerPara = 60): string {
  const out: string[] = [];
  for (let p = 0; p < paragraphs; p++) {
    const words: string[] = [];
    for (let i = 0; i < wordsPerPara; i++) words.push(SOURCE[Math.floor(Math.random() * SOURCE.length)]);
    let s = words.join(" ");
    s = s.charAt(0).toUpperCase() + s.slice(1) + ".";
    out.push(s);
  }
  return out.join("\n\n");
}

export default function LoremIpsum() {
  const [n, setN] = useState(3);
  const [text, setText] = useState(() => gen(3));
  return (
    <div className="space-y-4">
      <div className="flex items-end gap-3">
        <div>
          <Label htmlFor="n">Paragraphs</Label>
          <Input id="n" type="number" min={1} max={20} value={n} onChange={(e) => setN(Number(e.target.value))} className="w-28" />
        </div>
        <Button onClick={() => setText(gen(n))} className="bg-gradient-brand text-brand-foreground">Generate</Button>
        <Button variant="outline" onClick={async () => { await navigator.clipboard.writeText(text); toast.success("Copied"); }}>Copy</Button>
      </div>
      <Textarea value={text} onChange={(e) => setText(e.target.value)} className="min-h-[400px]" />
    </div>
  );
}
