import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function UuidGenerator() {
  const [n, setN] = useState(8);
  const [uuids, setUuids] = useState<string[]>(() => Array.from({ length: 8 }, () => crypto.randomUUID()));
  return (
    <div className="max-w-2xl space-y-4">
      <div className="flex items-end gap-3">
        <div>
          <Label htmlFor="n">How many</Label>
          <Input id="n" type="number" min={1} max={100} value={n} onChange={(e) => setN(Number(e.target.value))} className="w-28" />
        </div>
        <Button onClick={() => setUuids(Array.from({ length: n }, () => crypto.randomUUID()))} className="bg-gradient-brand text-brand-foreground">Generate</Button>
        <Button variant="outline" onClick={async () => { await navigator.clipboard.writeText(uuids.join("\n")); toast.success("Copied"); }}>Copy all</Button>
      </div>
      <div className="rounded-2xl border border-border bg-card p-4 font-mono text-sm space-y-1">
        {uuids.map((u, i) => <div key={i}>{u}</div>)}
      </div>
    </div>
  );
}
