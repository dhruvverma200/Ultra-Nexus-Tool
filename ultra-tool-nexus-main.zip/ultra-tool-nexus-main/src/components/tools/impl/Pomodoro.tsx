import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Pomodoro() {
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const ref = useRef<number | null>(null);
  useEffect(() => {
    if (!running) return;
    ref.current = window.setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, [running]);
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  return (
    <Card className="mx-auto max-w-md p-10 text-center">
      <div className="font-display text-7xl font-bold tabular-nums text-gradient-brand">{mm}:{ss}</div>
      <div className="mt-6 flex justify-center gap-2">
        <Button onClick={() => setRunning((r) => !r)} className="bg-gradient-brand text-brand-foreground">{running ? "Pause" : "Start"}</Button>
        <Button variant="outline" onClick={() => { setRunning(false); setSeconds(25 * 60); }}>Reset</Button>
      </div>
      <div className="mt-4 flex justify-center gap-2">
        {[25, 15, 5].map((m) => <Button key={m} variant="ghost" size="sm" onClick={() => { setRunning(false); setSeconds(m * 60); }}>{m}m</Button>)}
      </div>
    </Card>
  );
}
