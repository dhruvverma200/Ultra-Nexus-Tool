import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function PercentageCalculator() {
  const [a, setA] = useState(20);
  const [b, setB] = useState(200);
  return (
    <div className="max-w-xl space-y-4">
      <Card className="p-6 grid gap-3 sm:grid-cols-2">
        <div><Label>What is X%</Label><Input type="number" value={a} onChange={(e) => setA(Number(e.target.value))} /></div>
        <div><Label>of Y</Label><Input type="number" value={b} onChange={(e) => setB(Number(e.target.value))} /></div>
      </Card>
      <Card className="p-6 text-center">
        <div className="text-xs text-muted-foreground">{a}% of {b}</div>
        <div className="mt-1 font-display text-4xl font-bold text-gradient-brand">{((a * b) / 100).toFixed(2)}</div>
      </Card>
      <Card className="p-6 text-center">
        <div className="text-xs text-muted-foreground">{a} is what % of {b}</div>
        <div className="mt-1 font-display text-2xl font-bold">{b ? ((a / b) * 100).toFixed(2) : "—"}%</div>
      </Card>
    </div>
  );
}
