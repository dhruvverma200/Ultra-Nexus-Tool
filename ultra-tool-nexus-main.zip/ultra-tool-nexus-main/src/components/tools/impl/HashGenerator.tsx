import { useEffect, useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { Copy } from "lucide-react";

async function digest(algo: string, text: string): Promise<string> {
  const buf = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest(algo, buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

export default function HashGenerator() {
  const [t, setT] = useState("");
  const [hashes, setHashes] = useState<Record<string, string>>({});
  useEffect(() => {
    (async () => {
      if (!t) { setHashes({}); return; }
      const [a, b, c] = await Promise.all([
        digest("SHA-1", t), digest("SHA-256", t), digest("SHA-512", t),
      ]);
      setHashes({ "SHA-1": a, "SHA-256": b, "SHA-512": c });
    })();
  }, [t]);

  return (
    <div className="space-y-4">
      <Textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Text to hash…" className="min-h-[160px]" />
      <p className="text-xs text-muted-foreground">MD5 is intentionally omitted — it's broken. Use SHA-256+.</p>
      <div className="grid gap-3">
        {Object.entries(hashes).map(([algo, h]) => (
          <Card key={algo} className="p-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-medium text-brand">{algo}</div>
              <div className="mt-1 break-all font-mono text-sm">{h}</div>
            </div>
            <button onClick={async () => { await navigator.clipboard.writeText(h); toast.success("Copied"); }} className="text-muted-foreground hover:text-foreground"><Copy className="h-4 w-4" /></button>
          </Card>
        ))}
      </div>
    </div>
  );
}
