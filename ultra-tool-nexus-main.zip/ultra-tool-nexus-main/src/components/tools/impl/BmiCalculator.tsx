import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function BmiCalculator() {
  const [h, setH] = useState(170);
  const [w, setW] = useState(65);
  const bmi = w / Math.pow(h / 100, 2);
  let cat = "—";
  if (bmi < 18.5) cat = "Underweight";
  else if (bmi < 25) cat = "Healthy";
  else if (bmi < 30) cat = "Overweight";
  else cat = "Obese";
  return (
    <div className="max-w-xl space-y-4">
      <Card className="p-6 space-y-3">
        <div><Label>Height (cm)</Label><Input type="number" value={h} onChange={(e) => setH(Number(e.target.value))} /></div>
        <div><Label>Weight (kg)</Label><Input type="number" value={w} onChange={(e) => setW(Number(e.target.value))} /></div>
      </Card>
      <Card className="p-6 text-center">
        <div className="text-xs text-muted-foreground">Your BMI</div>
        <div className="mt-1 font-display text-5xl font-bold text-gradient-brand">{isFinite(bmi) ? bmi.toFixed(1) : "—"}</div>
        <div className="mt-2 text-sm font-medium">{cat}</div>
      </Card>
    </div>
  );
}
