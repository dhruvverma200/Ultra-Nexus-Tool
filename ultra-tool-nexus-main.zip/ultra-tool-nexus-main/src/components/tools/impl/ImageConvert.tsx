import { useState } from "react";
import { FileDropZone } from "@/components/FileDropZone";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ImageConvert() {
  const [file, setFile] = useState<File | null>(null);
  const [fmt, setFmt] = useState("image/png");
  const [out, setOut] = useState<string | null>(null);

  async function run() {
    if (!file) return;
    const bmp = await createImageBitmap(file);
    const canvas = document.createElement("canvas");
    canvas.width = bmp.width; canvas.height = bmp.height;
    canvas.getContext("2d")!.drawImage(bmp, 0, 0);
    const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), fmt, 0.9));
    setOut(URL.createObjectURL(blob));
  }

  const ext = fmt.split("/")[1];
  return (
    <div className="space-y-4">
      <FileDropZone accept="image/*" onFiles={(f) => { setFile(f[0]); setOut(null); }} />
      {file && (
        <Card className="p-5 space-y-4">
          <div className="text-sm">{file.name}</div>
          <div>
            <Label>Target format</Label>
            <Select value={fmt} onValueChange={setFmt}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="image/png">PNG</SelectItem>
                <SelectItem value="image/jpeg">JPG</SelectItem>
                <SelectItem value="image/webp">WebP</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={run} className="bg-gradient-brand text-brand-foreground">Convert</Button>
          {out && (
            <Button asChild variant="outline"><a href={out} download={`converted.${ext}`}>Download .{ext}</a></Button>
          )}
        </Card>
      )}
    </div>
  );
}
