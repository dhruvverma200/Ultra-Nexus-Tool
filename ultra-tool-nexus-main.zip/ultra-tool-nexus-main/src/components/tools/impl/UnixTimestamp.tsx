import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function UnixTimestamp() {
  const [ts, setTs] = useState(() => String(Math.floor(Date.now() / 1000)));
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 19));
  const d = new Date(Number(ts) * 1000);
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card className="p-6 space-y-3">
        <Label>Unix timestamp (seconds)</Label>
        <Input value={ts} onChange={(e) => setTs(e.target.value)} className="font-mono" />
        <div className="text-sm text-muted-foreground">UTC: {isNaN(d.getTime()) ? "—" : d.toUTCString()}</div>
        <div className="text-sm text-muted-foreground">Local: {isNaN(d.getTime()) ? "—" : d.toString()}</div>
      </Card>
      <Card className="p-6 space-y-3">
        <Label>Date → timestamp</Label>
        <Input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} />
        <div className="text-sm">Unix: <span className="font-mono">{Math.floor(new Date(date).getTime() / 1000) || "—"}</span></div>
      </Card>
    </div>
  );
}
