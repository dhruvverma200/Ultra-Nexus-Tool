import { useEffect, useState } from "react";
import { FileDropZone } from "@/components/FileDropZone";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function ImageResize() {
  const [file, setFile] = useState<File | null>(null);
  const [w, setW] = useState(800);
  const [h, setH] = useState(600);
  const [origin, setOrigin] = useState<{ w: number; h: number } | null>(null);
  const [out, setOut] = useState<string | null>(null);

  useEffect(() => {
    if (!file) return;
    createImageBitmap(file).then((bmp) => { setOrigin({ w: bmp.width, h: bmp.height }); setW(bmp.width); setH(bmp.height); });
  }, [file]);

  async function run() {
    if (!file) return;
    const bmp = await createImageBitmap(file);
    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    canvas.getContext("2d")!.drawImage(bmp, 0, 0, w, h);
    const blob: Blob = await new Promise((r) => canvas.toBlob((b) => r(b!), file.type || "image/png"));
    setOut(URL.createObjectURL(blob));
  }

  return (
    <div className="space-y-4">
      <FileDropZone accept="image/*" onFiles={(f) => { setFile(f[0]); setOut(null); }} />
      {file && (
        <Card className="p-5 space-y-4">
          <div className="text-sm text-muted-foreground">Original: {origin?.w}×{origin?.h}</div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Width</Label><Input type="number" value={w} onChange={(e) => setW(Number(e.target.value))} /></div>
            <div><Label>Height</Label><Input type="number" value={h} onChange={(e) => setH(Number(e.target.value))} /></div>
          </div>
          <Button onClick={run} className="bg-gradient-brand text-brand-foreground">Resize</Button>
          {out && (
            <div className="space-y-2">
              <img src={out} alt="" className="max-h-72 rounded-lg border border-border" />
              <Button asChild variant="outline"><a href={out} download={`resized-${file.name}`}>Download</a></Button>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
