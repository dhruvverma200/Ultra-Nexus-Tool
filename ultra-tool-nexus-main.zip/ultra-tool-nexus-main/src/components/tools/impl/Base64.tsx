import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Base64() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");

  function encode() {
    try { setOutput(btoa(unescape(encodeURIComponent(input)))); } catch (e: any) { toast.error(e.message); }
  }
  function decode() {
    try { setOutput(decodeURIComponent(escape(atob(input)))); } catch (e: any) { toast.error("Invalid Base64"); }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Input" className="min-h-[360px]" />
      <div className="space-y-3">
        <Textarea readOnly value={output} placeholder="Output" className="min-h-[280px] bg-muted/30" />
        <div className="flex gap-2">
          <Button onClick={encode} className="bg-gradient-brand text-brand-foreground">Encode</Button>
          <Button variant="outline" onClick={decode}>Decode</Button>
          <Button variant="ghost" onClick={async () => { await navigator.clipboard.writeText(output); toast.success("Copied"); }}>Copy</Button>
        </div>
      </div>
    </div>
  );
}
