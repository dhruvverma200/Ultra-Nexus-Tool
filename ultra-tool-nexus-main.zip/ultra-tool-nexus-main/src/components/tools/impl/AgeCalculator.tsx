import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

export default function AgeCalculator() {
  const [dob, setDob] = useState("2000-01-01");
  const now = new Date();
  const d = new Date(dob);
  let years = now.getFullYear() - d.getFullYear();
  let months = now.getMonth() - d.getMonth();
  let days = now.getDate() - d.getDate();
  if (days < 0) { months -= 1; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
  if (months < 0) { years -= 1; months += 12; }
  const totalDays = Math.floor((now.getTime() - d.getTime()) / (86400000));
  return (
    <div className="max-w-xl space-y-4">
      <Card className="p-6 space-y-3">
        <Label>Your date of birth</Label>
        <Input type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
      </Card>
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-5 text-center"><div className="text-xs text-muted-foreground">Years</div><div className="font-display text-3xl font-bold text-gradient-brand">{years}</div></Card>
        <Card className="p-5 text-center"><div className="text-xs text-muted-foreground">Months</div><div className="font-display text-3xl font-bold">{months}</div></Card>
        <Card className="p-5 text-center"><div className="text-xs text-muted-foreground">Days</div><div className="font-display text-3xl font-bold">{days}</div></Card>
      </div>
      <Card className="p-5"><div className="text-xs text-muted-foreground">Total days lived</div><div className="font-display text-2xl font-bold">{totalDays.toLocaleString()}</div></Card>
    </div>
  );
}
