import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const ops = {
  UPPER: (s: string) => s.toUpperCase(),
  lower: (s: string) => s.toLowerCase(),
  "Title Case": (s: string) => s.replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase()),
  "Sentence case": (s: string) => s.toLowerCase().replace(/(^|[.!?]\s+)(\w)/g, (_, p, c) => p + c.toUpperCase()),
  "kebab-case": (s: string) => s.trim().toLowerCase().replace(/\s+/g, "-"),
  snake_case: (s: string) => s.trim().toLowerCase().replace(/\s+/g, "_"),
  camelCase: (s: string) => s.trim().toLowerCase().replace(/[^a-z0-9]+(.)/g, (_, c) => c.toUpperCase()),
  "iNVERSE cASE": (s: string) => s.split("").map((c) => (c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase())).join(""),
};

export default function CaseConverter() {
  const [t, setT] = useState("");
  return (
    <div className="space-y-4">
      <Textarea value={t} onChange={(e) => setT(e.target.value)} placeholder="Enter text…" className="min-h-[200px]" />
      <div className="flex flex-wrap gap-2">
        {Object.entries(ops).map(([label, fn]) => (
          <Button key={label} variant="outline" onClick={() => setT(fn(t))}>{label}</Button>
        ))}
        <Button onClick={async () => { await navigator.clipboard.writeText(t); toast.success("Copied"); }} className="bg-gradient-brand text-brand-foreground">Copy</Button>
      </div>
    </div>
  );
}
