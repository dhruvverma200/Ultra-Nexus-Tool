
This request bundles four big tracks. To keep quality high (and not break working features) I'll ship in phases and check in between. Approve and I'll start with Phase 1.

## Phase 1 — Razorpay end-to-end (functional, no UI redesign yet)
- Verify current `src/lib/razorpay.functions.ts`, `src/lib/razorpay.ts`, and `/api/public/razorpay-webhook` flow.
- Create Razorpay Order on server (`createOrder` server fn) with amount, currency, plan metadata; sign `notes` with `uid`/`plan`.
- Client checkout: load `https://checkout.razorpay.com/v1/checkout.js` on demand, open Razorpay modal from `/dashboard/subscription` for Trial ₹1, Pro Monthly, Pro Annual.
- Verify payment signature (`verifyPayment` server fn) using `RAZORPAY_KEY_SECRET`; on success write `subscriptions/{uid}` doc: `{ plan, status:'active', trialUsed (if trial), currentPeriodEnd, autopayPlan, lastPaymentId }`.
- Webhook (`payment.captured`, `subscription.charged`, `subscription.cancelled`): verify HMAC, then update Firestore via Firebase Admin SDK (add `firebase-admin` + service-account secret as `FIREBASE_SERVICE_ACCOUNT_JSON`). Add audit log entry.
- ₹1 trial guard: server fn rejects order if `subscriptions/{uid}.trialUsed === true`.
- Idempotency: store `processedEvents/{eventId}` to skip duplicate webhook deliveries.

Manual you'll do: paste `RAZORPAY_KEY_ID` (public), `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `FIREBASE_SERVICE_ACCOUNT_JSON`, and set webhook URL in Razorpay dashboard.

## Phase 2 — Admin lock + auth polish
- Hard-lock admin to `shouryverma29@gmail.com`:
  - On login, if email matches and no `user_roles/{uid}` doc, create `{ role:'admin' }`.
  - `ProtectedRoute requireAdmin` + Firestore rules already gate writes; tighten rules so only that email can self-promote.
- Google Sign-In: confirm popup flow + redirect fallback on mobile.
- Forgot password: confirm `sendPasswordResetEmail` works; `/reset-password` handles `oobCode` via `verifyPasswordResetCode` → `confirmPasswordReset` and redirects to `/auth`.
- Admin pages (`/admin/blog`, `/admin/contact`, `/admin/ads`, `/admin/settings`, `/admin/users`) get working CRUD against Firestore so you can edit About, Contact, Pricing copy and publish blog posts.

## Phase 3 — Tools audit (target: 101 working tools)
- Walk `src/lib/tools.ts`: ensure 101 entries, unique slugs, unique Lucide icons, correct categories.
- Verify `ToolRunner` dispatch: each slug routes to its own component (no wrong-tool bug). Add a dev-only test that maps every implemented slug to a non-empty component.
- Implement the remaining priority tools client-side where feasible (QR, Barcode, Regex Tester, CSV→JSON, XML Formatter, Markdown Editor, Text Diff, Color Converter, CSS/JS/HTML/SQL Formatters, IP Lookup via free API, HTTP Status Codes, Unit/Currency/Loan/Date/Tip calculators, Notes via Firestore, URL Shortener via Firestore, Favicon Generator). Heavy media tools (video compress, OCR, remove-bg) get a clearly-labeled "Pro / coming soon" state instead of silently failing.

## Phase 4 — Premium UI redesign (no logic changes)
Design system only — does not touch Firebase, routes, or business logic.

- Tokens (`src/styles.css`): refine OKLCH palette (deep indigo+violet+cyan), tighter spacing scale, 16px default radius, two shadow tiers (`shadow-soft`, `shadow-glow`), real glass tokens. Dark mode primary, light secondary, system auto via `prefers-color-scheme` + manual switcher in header (persist in `localStorage`).
- Typography: keep Space Grotesk display + Inter body, set tracking/leading globally.
- Components: rebuild `Header` (floating glass nav + theme toggle + search + profile menu), `Footer`, `PageShell`, `ToolCard` (hover lift, gradient border on hover), `FileDropZone` (animated dashed border, progress, success check), `Button` variants (primary gradient, glass secondary, ghost, destructive, loading state), `Input` (floating labels, focus ring, password eye), `Table` (sticky header, rounded rows, pagination), skeletons, empty states.
- Pages redesigned to match Linear/Vercel quality: Landing, Pricing, Tools index, Tool detail, Auth, Dashboard shell + sidebar (animated active pill, collapsible), Dashboard overview (welcome banner, usage rings, recent activity, favorite tools, subscription card), Profile, Subscription, History, Admin shell.
- Motion: Framer Motion fade/slide/scale/stagger on route mount and card grids; respect `prefers-reduced-motion`.
- New favicon: regenerate premium violet→cyan "O" mark at `public/favicon.png` + add `favicon.svg` and apple-touch-icon.
- Responsive pass at 360 / 768 / 1280 / 1920.
- A11y: focus rings, aria labels on icon buttons, color contrast AA, keyboard nav for sidebar/menu.

## Phase 5 — Verification
- `tsgo` typecheck, build, fix errors.
- Playwright smoke: signup → verify email screen, Google button renders, forgot-password sends, reset page mounts with mock oobCode, dashboard loads, one tool from each category runs, Razorpay modal opens (test key), webhook verified via curl with signed payload.

---

### Out of scope unless you confirm
- Real SMS/OTP, real email sending beyond Firebase Auth defaults.
- Server-side video/image processing (needs a separate worker — Cloudflare Worker runtime can't run ffmpeg/sharp).
- Migrating off TanStack Start.

Reply "go" to start Phase 1, or tell me to reorder (e.g. "UI first").
